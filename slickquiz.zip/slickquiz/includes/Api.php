<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_Api {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {
        register_rest_route('slickquiz/v1', '/attempts', [
            'methods'             => 'POST',
            'permission_callback' => '__return_true',
            'callback'            => [$this, 'create_attempt'],
        ]);

        register_rest_route('slickquiz/v1', '/attempts/(?P<id>\d+)/complete', [
            'methods'             => 'POST',
            'permission_callback' => '__return_true',
            'callback'            => [$this, 'complete_attempt'],
        ]);
    }

    public function create_attempt(WP_REST_Request $req) {
        $quiz_id = (int)$req->get_param('quiz_id');
        if (!$quiz_id) return new WP_Error('bad_request', 'quiz_id required', ['status' => 400]);

        $user_id    = get_current_user_id();
        $attempt_id = SlickQuiz_QuizRepo::create_attempt($quiz_id, $user_id);

        return new WP_REST_Response(['attempt_id' => $attempt_id], 200);
    }

    public function complete_attempt(WP_REST_Request $req) {
        $attempt_id = (int)$req['id'];
        $quiz_id    = (int)$req->get_param('quiz_id');
        $answers    = $req->get_param('answers');

        if (!$attempt_id || !$quiz_id) return new WP_Error('bad_request', 'attempt_id/quiz_id required', ['status' => 400]);
        if (!is_array($answers))        return new WP_Error('bad_request', 'answers must be array', ['status' => 400]);

        // Load quiz for server-side scoring
        $quiz = SlickQuiz_QuizRepo::get_quiz($quiz_id);
        if (!$quiz) return new WP_Error('not_found', 'Quiz not found', ['status' => 404]);

        $result_bundle = SlickQuiz_QuizRepo::compute_result_bundle($quiz, $answers);

        $user_id = get_current_user_id();
        $ok      = SlickQuiz_QuizRepo::complete_attempt($attempt_id, $quiz_id, $user_id, $answers, $result_bundle);
        if (is_wp_error($ok)) return $ok;

        return new WP_REST_Response(['ok' => true, 'resultBundle' => $result_bundle], 200);
    }
}
