<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_QuizRepo {

    public static function list_quizzes() {
        global $wpdb;
        $t = $wpdb->prefix . 'slickquiz_quizzes';
        return $wpdb->get_results("SELECT * FROM $t ORDER BY updated_at DESC", ARRAY_A);
    }

    public static function get_quiz($quiz_id) {
        global $wpdb;
        $qz = $wpdb->prefix . 'slickquiz_quizzes';
        $qs = $wpdb->prefix . 'slickquiz_questions';
        $op = $wpdb->prefix . 'slickquiz_options';
        $ct = $wpdb->prefix . 'slickquiz_result_categories';

        $quiz = $wpdb->get_row($wpdb->prepare("SELECT * FROM $qz WHERE id=%d", $quiz_id), ARRAY_A);
        if (!$quiz) return null;

        $questions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $qs WHERE quiz_id=%d ORDER BY position ASC, id ASC",
            $quiz_id
        ), ARRAY_A);

        $question_ids = array_map(fn($r) => (int)$r['id'], $questions);
        $options_by_q = [];

        if (!empty($question_ids)) {
            $placeholders = implode(',', array_fill(0, count($question_ids), '%d'));
            $sql = $wpdb->prepare(
                "SELECT * FROM $op WHERE question_id IN ($placeholders) ORDER BY question_id ASC, position ASC, id ASC",
                ...$question_ids
            );
            $opts = $wpdb->get_results($sql, ARRAY_A);
            foreach ($opts as $o) {
                $qid = (int)$o['question_id'];
                if (!isset($options_by_q[$qid])) $options_by_q[$qid] = [];
                $options_by_q[$qid][] = $o;
            }
        }

        foreach ($questions as &$q) {
            $qid = (int)$q['id'];
            $q['options'] = $options_by_q[$qid] ?? [];
        }

        $quiz['questions'] = $questions;

        // Load result categories
        $quiz['categories'] = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $ct WHERE quiz_id=%d ORDER BY category_set_key ASC, position ASC, id ASC",
            $quiz_id
        ), ARRAY_A);

        return $quiz;
    }

    public static function create_quiz($title, $slug, $results_module_js, $meta_json) {
        global $wpdb;
        $t = $wpdb->prefix . 'slickquiz_quizzes';
        $wpdb->insert($t, [
            'title'             => $title,
            'slug'              => $slug,
            'results_module_js' => $results_module_js ?: null,
            'meta_json'         => $meta_json,
        ], ['%s','%s','%s','%s']);
        return (int)$wpdb->insert_id;
    }

    public static function update_quiz($quiz_id, $title, $slug, $results_module_js = '', $meta_json = null) {
        global $wpdb;
        $qz = $wpdb->prefix . 'slickquiz_quizzes';
        $wpdb->update($qz, [
            'title'             => $title,
            'slug'              => $slug,
            'results_module_js' => $results_module_js ?: null,
            'meta_json'         => $meta_json,
        ], ['id' => (int)$quiz_id], ['%s','%s','%s','%s'], ['%d']);
        return true;
    }

    public static function get_quiz_by_slug($slug) {
        global $wpdb;
        $qz = $wpdb->prefix . 'slickquiz_quizzes';

        $slug = sanitize_title($slug);
        $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM $qz WHERE slug=%s LIMIT 1", $slug), ARRAY_A);
        if (!$row) return null;

        return self::get_quiz((int)$row['id']);
    }

    public static function replace_questions_and_options($quiz_id, $questions_payload) {
        global $wpdb;
        $qs = $wpdb->prefix . 'slickquiz_questions';
        $op = $wpdb->prefix . 'slickquiz_options';

        // Delete existing
        $existing_qids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $qs WHERE quiz_id=%d", $quiz_id));
        if (!empty($existing_qids)) {
            $placeholders = implode(',', array_fill(0, count($existing_qids), '%d'));
            $wpdb->query($wpdb->prepare("DELETE FROM $op WHERE question_id IN ($placeholders)", ...$existing_qids));
        }
        $wpdb->query($wpdb->prepare("DELETE FROM $qs WHERE quiz_id=%d", $quiz_id));

        // Insert fresh
        $pos = 0;
        foreach ($questions_payload as $q) {
            $q_config = ['show_info_after' => (bool)($q['show_info_after'] ?? false)];
            $wpdb->insert($qs, [
                'quiz_id' => $quiz_id,
                'position' => $pos++,
                'title' => $q['title'],
                'type' => $q['type'],
                'config_json' => wp_json_encode($q_config),
            ], ['%d','%d','%s','%s','%s']);
            $qid = (int)$wpdb->insert_id;

            $op_pos = 0;
            foreach ($q['options'] as $o) {
                $config = [
                    'scores'                  => $o['scores'] ?? [],
                    'info_image_attachment_id' => (int)($o['info_image_attachment_id'] ?? 0) ?: null,
                    'info_message'            => (string)($o['info_message'] ?? ''),
                ];
                $wpdb->insert($op, [
                    'question_id' => $qid,
                    'position' => $op_pos++,
                    'label' => $o['label'],
                    'image_attachment_id' => $o['image_attachment_id'] ?: null,
                    'config_json' => wp_json_encode($config),
                ], ['%d','%d','%s','%d','%s']);
            }
        }
    }

    public static function replace_categories($quiz_id, $categories_payload) {
        global $wpdb;
        $t = $wpdb->prefix . 'slickquiz_result_categories';

        $wpdb->query($wpdb->prepare("DELETE FROM $t WHERE quiz_id=%d", $quiz_id));

        foreach ($categories_payload as $c) {
            $wpdb->insert($t, [
                'quiz_id'              => (int)$quiz_id,
                'category_set_key'     => $c['category_set_key'],
                'position'             => (int)$c['position'],
                'title'                => $c['title'],
                'description'          => $c['description'],
                'image_attachment_id'  => $c['image_attachment_id'] ?: null,
                'scores_json'          => wp_json_encode($c['scores']),
            ], ['%d','%s','%d','%s','%s','%d','%s']);
        }
    }

    /**
     * Compute the standardised result bundle from quiz + answers.
     * Returns an array ready for JSON-encoding and saving.
     */
    public static function compute_result_bundle($quiz, $answers_payload) {
        $meta          = json_decode($quiz['meta_json'] ?? '{}', true) ?: [];
        $vectors       = $meta['scoring_vectors'] ?? [];
        $catsets_meta  = $meta['category_sets'] ?? [];
        $vector_keys   = array_column($vectors, 'key');

        // Index questions and options
        $questions_by_id = [];
        foreach ($quiz['questions'] as $q) {
            $questions_by_id[(int)$q['id']] = $q;
        }

        // Accumulate user scores
        $user_scores        = array_fill_keys($vector_keys, 0.0);
        $contributing_count = array_fill_keys($vector_keys, 0);

        foreach ($answers_payload as $a) {
            $qid = (int)($a['question_id'] ?? 0);
            $q   = $questions_by_id[$qid] ?? null;
            if (!$q) continue;

            if ($a['type'] === 'slider') {
                // Interpolate between left (index 0) and right (index 1) option scores
                $v            = (float)($a['value'] ?? 0);
                $weight_right = ($v + 100) / 200.0;
                $weight_left  = 1.0 - $weight_right;

                $left_scores  = self::option_scores($q['options'][0] ?? null);
                $right_scores = self::option_scores($q['options'][1] ?? null);

                foreach ($vector_keys as $vk) {
                    $blended = $weight_left * (float)($left_scores[$vk] ?? 0)
                             + $weight_right * (float)($right_scores[$vk] ?? 0);
                    $user_scores[$vk]        += $blended;
                    $contributing_count[$vk] += 1;
                }
            } else {
                $oid = (int)($a['option_id'] ?? 0);
                $opt = null;
                foreach ($q['options'] as $o) {
                    if ((int)$o['id'] === $oid) { $opt = $o; break; }
                }
                if (!$opt) continue;

                $opt_scores = self::option_scores($opt);
                foreach ($vector_keys as $vk) {
                    $user_scores[$vk]        += (float)($opt_scores[$vk] ?? 0);
                    $contributing_count[$vk] += 1;
                }
            }
        }

        // Normalize to average
        $normalized_scores = [];
        foreach ($vector_keys as $vk) {
            $cnt = $contributing_count[$vk];
            $normalized_scores[$vk] = $cnt > 0 ? round($user_scores[$vk] / $cnt, 6) : 0.0;
        }

        // Build category sets with similarity scores
        $sets_by_key = [];
        foreach ($catsets_meta as $s) {
            $sets_by_key[$s['key']] = ['key' => $s['key'], 'label' => $s['label'], 'categories' => []];
        }

        foreach (($quiz['categories'] ?? []) as $cat) {
            $set_key    = $cat['category_set_key'];
            $cat_scores = json_decode($cat['scores_json'] ?? '{}', true) ?: [];
            $similarity = self::cosine_similarity($normalized_scores, $cat_scores, $vector_keys);

            $img_url = '';
            $img_att = (int)($cat['image_attachment_id'] ?? 0);
            if ($img_att) {
                $src = wp_get_attachment_image_src($img_att, 'large');
                if ($src) $img_url = $src[0];
            }

            if (!isset($sets_by_key[$set_key])) {
                $sets_by_key[$set_key] = ['key' => $set_key, 'label' => $set_key, 'categories' => []];
            }
            $sets_by_key[$set_key]['categories'][] = [
                'id'          => (int)$cat['id'],
                'title'       => (string)$cat['title'],
                'description' => (string)($cat['description'] ?? ''),
                'imageUrl'    => $img_url,
                'scores'      => $cat_scores,
                'similarity'  => round($similarity, 6),
            ];
        }

        // Sort each set by similarity descending
        foreach ($sets_by_key as &$set) {
            usort($set['categories'], fn($a, $b) => $b['similarity'] <=> $a['similarity']);
        }
        unset($set);

        return [
            'scores'       => $normalized_scores,
            'vectors'      => $vectors,
            'categorySets' => array_values($sets_by_key),
        ];
    }

    // ---------------------------------------------------------------
    // Attempts

    public static function create_attempt($quiz_id, $user_id) {
        global $wpdb;
        $t = $wpdb->prefix . 'slickquiz_attempts';

        $ua      = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 1000) : null;
        $ip      = $_SERVER['REMOTE_ADDR'] ?? '';
        $ip_hash = $ip ? hash('sha256', $ip) : null;

        $wpdb->insert($t, [
            'quiz_id'    => (int)$quiz_id,
            'user_id'    => (int)$user_id,
            'user_agent' => $ua,
            'ip_hash'    => $ip_hash,
        ], ['%d','%d','%s','%s']);

        return (int)$wpdb->insert_id;
    }

    public static function attempt_belongs_to_user($attempt_id, $user_id) {
        global $wpdb;
        $t = $wpdb->prefix . 'slickquiz_attempts';
        $v = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE id=%d AND user_id=%d", $attempt_id, $user_id));
        return ((int)$v) === 1;
    }

    public static function complete_attempt($attempt_id, $quiz_id, $user_id, $answers_payload, $result_bundle) {
        global $wpdb;

        $t_attempts = $wpdb->prefix . 'slickquiz_attempts';
        $t_answers  = $wpdb->prefix . 'slickquiz_answers';
        $t_results  = $wpdb->prefix . 'slickquiz_results';

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t_attempts WHERE id=%d", $attempt_id), ARRAY_A);
        if (!$row) return new WP_Error('not_found', 'Attempt not found', ['status' => 404]);
        if ((int)$row['user_id'] !== (int)$user_id) return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
        if ((int)$row['quiz_id'] !== (int)$quiz_id) return new WP_Error('bad_request', 'Quiz mismatch', ['status' => 400]);

        $wpdb->update($t_attempts, [
            'completed_at' => current_time('mysql'),
        ], ['id' => $attempt_id], ['%s'], ['%d']);

        $wpdb->query($wpdb->prepare("DELETE FROM $t_answers WHERE attempt_id=%d", $attempt_id));

        foreach ($answers_payload as $a) {
            $qid = (int)($a['question_id'] ?? 0);
            if (!$qid) continue;
            $wpdb->insert($t_answers, [
                'attempt_id'  => (int)$attempt_id,
                'question_id' => $qid,
                'answer_json' => wp_json_encode($a),
            ], ['%d','%d','%s']);
        }

        $existing = $wpdb->get_var($wpdb->prepare("SELECT attempt_id FROM $t_results WHERE attempt_id=%d", $attempt_id));
        $json     = wp_json_encode($result_bundle ?: new stdClass());

        if ($existing) {
            $wpdb->update($t_results, [
                'result_json' => $json,
                'computed_at' => current_time('mysql'),
                'version'     => 'v1',
            ], ['attempt_id' => $attempt_id], ['%s','%s','%s'], ['%d']);
        } else {
            $wpdb->insert($t_results, [
                'attempt_id'  => (int)$attempt_id,
                'result_json' => $json,
                'computed_at' => current_time('mysql'),
                'version'     => 'v1',
            ], ['%d','%s','%s','%s']);
        }

        return true;
    }

    public static function list_attempts_with_answers_for_quiz($quiz_id) {
        global $wpdb;

        $t_attempts = $wpdb->prefix . 'slickquiz_attempts';
        $t_answers  = $wpdb->prefix . 'slickquiz_answers';
        $t_results  = $wpdb->prefix . 'slickquiz_results';
        $users      = $wpdb->users;

        $attempts = $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, u.user_login
            FROM $t_attempts a
            LEFT JOIN $users u ON u.ID = a.user_id
            WHERE a.quiz_id=%d
            ORDER BY a.started_at DESC, a.id DESC",
            $quiz_id
        ), ARRAY_A);

        if (empty($attempts)) return ['attempts' => [], 'answers' => [], 'results' => []];

        $attempt_ids  = array_map(fn($r) => (int)$r['id'], $attempts);
        $placeholders = implode(',', array_fill(0, count($attempt_ids), '%d'));

        $ans_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $t_answers WHERE attempt_id IN ($placeholders)",
            ...$attempt_ids
        ), ARRAY_A);

        $res_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $t_results WHERE attempt_id IN ($placeholders)",
            ...$attempt_ids
        ), ARRAY_A);

        $answers_by_attempt = [];
        foreach ($ans_rows as $r) {
            $aid = (int)$r['attempt_id'];
            if (!isset($answers_by_attempt[$aid])) $answers_by_attempt[$aid] = [];
            $answers_by_attempt[$aid][(int)$r['question_id']] = $r['answer_json'];
        }

        $results_by_attempt = [];
        foreach ($res_rows as $r) {
            $results_by_attempt[(int)$r['attempt_id']] = $r['result_json'];
        }

        return [
            'attempts' => $attempts,
            'answers'  => $answers_by_attempt,
            'results'  => $results_by_attempt,
        ];
    }

    // ---------------------------------------------------------------
    // Private helpers

    private static function option_scores(?array $opt): array {
        if (!$opt) return [];
        $cfg = json_decode($opt['config_json'] ?? '{}', true) ?: [];
        return $cfg['scores'] ?? [];
    }

    private static function cosine_similarity(array $a, array $b, array $keys): float {
        $dot    = 0.0;
        $norm_a = 0.0;
        $norm_b = 0.0;
        foreach ($keys as $k) {
            $av = (float)($a[$k] ?? 0);
            $bv = (float)($b[$k] ?? 0);
            $dot    += $av * $bv;
            $norm_a += $av * $av;
            $norm_b += $bv * $bv;
        }
        $denom = sqrt($norm_a) * sqrt($norm_b);
        if ($denom < 1e-10) return 0.0;
        return $dot / $denom;
    }
}
