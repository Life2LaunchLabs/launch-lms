<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_Activator {

    const SCHEMA_VERSION = '0.4.0';

    public static function activate() {
        self::run_migrations();
        flush_rewrite_rules();
    }

    /**
     * Called on plugins_loaded to catch installs that skipped activate hook.
     */
    public static function maybe_upgrade() {
        $current = get_option('slickquiz_schema_version', '0.0.0');
        if (version_compare($current, self::SCHEMA_VERSION, '<')) {
            self::run_migrations();
        }
    }

    private static function run_migrations() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();

        $quizzes    = $wpdb->prefix . 'slickquiz_quizzes';
        $questions  = $wpdb->prefix . 'slickquiz_questions';
        $options    = $wpdb->prefix . 'slickquiz_options';
        $attempts   = $wpdb->prefix . 'slickquiz_attempts';
        $answers    = $wpdb->prefix . 'slickquiz_answers';
        $results    = $wpdb->prefix . 'slickquiz_results';
        $categories = $wpdb->prefix . 'slickquiz_result_categories';

        $sql_quizzes = "CREATE TABLE $quizzes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL DEFAULT '',
            results_module_js LONGTEXT NULL,
            meta_json LONGTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY slug (slug)
        ) $charset_collate;";

        $sql_questions = "CREATE TABLE $questions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            quiz_id BIGINT UNSIGNED NOT NULL,
            position INT NOT NULL DEFAULT 0,
            title VARCHAR(255) NOT NULL DEFAULT '',
            type VARCHAR(32) NOT NULL,
            config_json LONGTEXT NULL,
            PRIMARY KEY (id),
            KEY quiz_id (quiz_id),
            KEY quiz_pos (quiz_id, position)
        ) $charset_collate;";

        $sql_options = "CREATE TABLE $options (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            question_id BIGINT UNSIGNED NOT NULL,
            position INT NOT NULL DEFAULT 0,
            label VARCHAR(255) NOT NULL DEFAULT '',
            image_attachment_id BIGINT UNSIGNED NULL,
            config_json LONGTEXT NULL,
            PRIMARY KEY (id),
            KEY question_id (question_id),
            KEY q_pos (question_id, position)
        ) $charset_collate;";

        $sql_attempts = "CREATE TABLE $attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            quiz_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at DATETIME NULL,
            user_agent TEXT NULL,
            ip_hash VARCHAR(64) NULL,
            PRIMARY KEY (id),
            KEY quiz_id (quiz_id),
            KEY user_id (user_id),
            KEY quiz_user (quiz_id, user_id)
        ) $charset_collate;";

        $sql_answers = "CREATE TABLE $answers (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            attempt_id BIGINT UNSIGNED NOT NULL,
            question_id BIGINT UNSIGNED NOT NULL,
            answer_json LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY attempt_id (attempt_id),
            KEY attempt_q (attempt_id, question_id)
        ) $charset_collate;";

        $sql_results = "CREATE TABLE $results (
            attempt_id BIGINT UNSIGNED NOT NULL,
            result_json LONGTEXT NOT NULL,
            computed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            version VARCHAR(32) NOT NULL DEFAULT 'v0',
            PRIMARY KEY (attempt_id)
        ) $charset_collate;";

        // New in 0.3.0: result categories
        $sql_categories = "CREATE TABLE $categories (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            quiz_id BIGINT UNSIGNED NOT NULL,
            category_set_key VARCHAR(100) NOT NULL DEFAULT '',
            position INT NOT NULL DEFAULT 0,
            title VARCHAR(255) NOT NULL DEFAULT '',
            description TEXT NULL,
            image_attachment_id BIGINT UNSIGNED NULL,
            scores_json LONGTEXT NULL,
            meta_json LONGTEXT NULL,
            PRIMARY KEY (id),
            KEY quiz_id (quiz_id),
            KEY quiz_set (quiz_id, category_set_key)
        ) $charset_collate;";

        dbDelta($sql_quizzes);
        dbDelta($sql_questions);
        dbDelta($sql_options);
        dbDelta($sql_attempts);
        dbDelta($sql_answers);
        dbDelta($sql_results);
        dbDelta($sql_categories);

        update_option('slickquiz_schema_version', self::SCHEMA_VERSION);
    }
}
