<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_Admin {

    const MENU_SLUG = 'slickquiz';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_post_slickquiz_save_quiz', [$this, 'handle_save_quiz']);
        add_action('admin_post_slickquiz_export_csv', [$this, 'handle_export_csv']);
    }

    public function register_menu() {
        add_menu_page(
            'SlickQuiz', 'SlickQuiz', 'manage_options',
            self::MENU_SLUG, [$this, 'render_list_page'],
            'dashicons-welcome-learn-more', 58
        );
        add_submenu_page(self::MENU_SLUG, 'Edit Quiz', 'Edit Quiz', 'manage_options', self::MENU_SLUG . '_edit', [$this, 'render_edit_page']);
        add_submenu_page(self::MENU_SLUG, 'Responses', 'Responses', 'manage_options', self::MENU_SLUG . '_responses', [$this, 'render_responses_page']);
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'slickquiz') === false) return;
        wp_enqueue_style('slickquiz-admin', SLICKQUIZ_URL . 'assets/admin.css', [], SLICKQUIZ_VERSION);
        wp_enqueue_media();
        wp_enqueue_script('slickquiz-admin', SLICKQUIZ_URL . 'assets/admin.js', ['jquery'], SLICKQUIZ_VERSION, true);
        wp_localize_script('slickquiz-admin', 'SlickQuizAdmin', ['nonce' => wp_create_nonce('slickquiz_admin')]);
    }

    // ---------------------------------------------------------------
    // List page

    public function render_list_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $quizzes = SlickQuiz_QuizRepo::list_quizzes();
        $new_url = admin_url('admin.php?page=' . self::MENU_SLUG . '_edit');

        echo '<div class="wrap slickquiz">';
        echo '<h1 class="wp-heading-inline">SlickQuiz</h1>';
        echo '<a class="page-title-action" href="' . esc_url($new_url) . '">+ New</a>';
        echo '<hr class="wp-header-end" />';
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Saved.</p></div>';

        echo '<table class="widefat striped slickquiz-table">';
        echo '<thead><tr><th>Title</th><th>Updated</th><th></th></tr></thead><tbody>';
        if (empty($quizzes)) {
            echo '<tr><td colspan="3">No quizzes yet.</td></tr>';
        } else {
            foreach ($quizzes as $q) {
                $edit_url      = admin_url('admin.php?page=' . self::MENU_SLUG . '_edit&quiz_id=' . intval($q['id']));
                $slug          = sanitize_title($q['slug'] ?: $q['title']);
                $view_url      = home_url('/quiz/' . rawurlencode($slug) . '/');
                $responses_url = admin_url('admin.php?page=' . self::MENU_SLUG . '_responses&quiz_id=' . intval($q['id']));
                echo '<tr>';
                echo '<td>' . esc_html($q['title']) . '</td>';
                echo '<td>' . esc_html($q['updated_at']) . '</td>';
                echo '<td style="text-align:right; white-space:nowrap;">';
                echo '<a class="button" href="' . esc_url($edit_url) . '">Edit</a> ';
                echo '<a class="button button-secondary" target="_blank" href="' . esc_url($view_url) . '">View</a> ';
                echo '<a class="button" href="' . esc_url($responses_url) . '">Responses</a>';
                echo '</td>';
                echo '</tr>';
            }
        }
        echo '</tbody></table></div>';
    }

    // ---------------------------------------------------------------
    // Edit page

    public function render_edit_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');

        $quiz_id    = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
        $quiz       = $quiz_id ? SlickQuiz_QuizRepo::get_quiz($quiz_id) : null;

        $title      = $quiz ? $quiz['title'] : '';
        $slug       = $quiz ? $quiz['slug'] : '';
        $results_module_js = $quiz ? ($quiz['results_module_js'] ?? '') : '';

        $meta       = $quiz ? (json_decode($quiz['meta_json'] ?? '{}', true) ?: []) : [];
        $vectors    = $meta['scoring_vectors'] ?? [];
        $catsets    = $meta['category_sets']   ?? [];
        $questions  = $quiz ? $quiz['questions'] : [];
        $categories = $quiz ? ($quiz['categories'] ?? []) : [];

        $back_url = admin_url('admin.php?page=' . self::MENU_SLUG);

        echo '<div class="wrap slickquiz">';
        echo '<h1>' . ($quiz_id ? 'Edit Quiz' : 'New Quiz') . '</h1>';
        echo '<a href="' . esc_url($back_url) . '">&larr; Back to list</a><hr/>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" enctype="multipart/form-data">';
        echo '<input type="hidden" name="action" value="slickquiz_save_quiz" />';
        wp_nonce_field('slickquiz_save_quiz', 'slickquiz_nonce');
        echo '<input type="hidden" name="quiz_id" value="' . intval($quiz_id) . '" />';
        // Slug is inferred from title server-side; hidden here to allow override if already set
        echo '<input type="hidden" name="slug" value="' . esc_attr($slug) . '" />';

        // Title block
        echo '<div class="sq-title-block">';
        echo '<input class="widefat" type="text" name="title" value="' . esc_attr($title) . '" placeholder="Quiz title" required />';
        echo '</div>';

        // Wizard navigation
        echo '<div class="sq-wizard-nav">';
        echo '<div class="sq-wizard-tab is-active" data-panel="sq-panel-questions">Questions</div>';
        echo '<div class="sq-wizard-tab" data-panel="sq-panel-scoring">Scoring</div>';
        echo '<div class="sq-wizard-tab" data-panel="sq-panel-results">Results</div>';
        echo '</div>';

        // ── Panel: Questions ─────────────────────────────────────────
        echo '<div class="sq-wizard-panel is-active" id="sq-panel-questions">';
        echo '<div class="slickquiz-card">';
        echo '<h2>Questions</h2>';
        echo '<div id="sq_questions">';
        if (empty($questions)) {
            $questions = [[
                'title' => '', 'type' => 'select_2',
                'options' => [
                    ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
                    ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
                ],
            ]];
        }
        foreach ($questions as $qi => $q) {
            $this->render_question_block($qi, $q, $vectors);
        }
        echo '</div>';
        echo '<div class="sq-list-add-row"><button type="button" class="button button-primary" id="sq_add_question">+ Add Question</button></div>';
        echo '</div>';
        echo '</div>'; // panel-questions

        // ── Panel: Scoring ───────────────────────────────────────────
        echo '<div class="sq-wizard-panel" id="sq-panel-scoring">';
        $this->render_scoring_card($vectors);
        $this->render_categories_card($categories, $catsets, $vectors);
        echo '</div>'; // panel-scoring

        // ── Panel: Results ───────────────────────────────────────────
        echo '<div class="sq-wizard-panel" id="sq-panel-results">';
        echo '<div class="slickquiz-card">';
        echo '<h2>Results Module</h2>';
        echo '<p class="description">Paste JS that defines <code>window.SlickQuizResults = { renderResults: function(el, resultBundle) { ... } }</code>. This script runs on the results page after the quiz is submitted.</p>';
        echo '<textarea name="results_module_js" id="sq_results_module_js" rows="20" class="large-text code" spellcheck="false" style="font-family:monospace;font-size:12px;">' . esc_textarea($results_module_js) . '</textarea>';
        echo '</div>';
        echo '</div>'; // panel-results

        echo '<p><button type="submit" class="button button-primary button-hero">Save Quiz</button></p>';
        echo '</form>';

        // JS Templates
        echo '<script type="text/template" id="sq_question_template">';
        $this->render_question_block('__INDEX__', [
            'title' => '', 'type' => 'select_2',
            'options' => [
                ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
                ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
            ],
        ], [], true);
        echo '</script>';

        echo '<script type="text/template" id="sq_option_template">';
        $this->render_option_block('__QINDEX__', '__OINDEX__', ['label' => '', 'image_attachment_id' => 0, 'config_json' => null], [], true);
        echo '</script>';

        echo '<script type="text/template" id="sq_vector_template">';
        $this->render_vector_row('__VINDEX__', ['key' => '', 'label' => '', 'type' => 'unidirectional', 'low_label' => '', 'high_label' => ''], true);
        echo '</script>';

        echo '<script type="text/template" id="sq_catset_tab_template">';
        $this->render_catset_tab('__SINDEX__', ['key' => '', 'label' => '']);
        echo '</script>';

        echo '<script type="text/template" id="sq_category_template">';
        $this->render_category_block('__CATINDEX__', [
            'id' => 0, 'title' => '', 'description' => '',
            'image_attachment_id' => 0, 'category_set_key' => '', 'scores_json' => '{}',
        ], [], true);
        echo '</script>';

        echo '</div>';
    }

    // ---------------------------------------------------------------
    // Scoring vectors card

    private function render_scoring_card($vectors) {
        echo '<div class="slickquiz-card">';
        echo '<h2>Scoring Vectors</h2>';
        echo '<p class="description">Dimensions used to score responses and match result categories. Key is auto-generated from the label.</p>';
        echo '<div id="sq_vectors">';
        foreach ($vectors as $vi => $v) {
            $this->render_vector_row($vi, $v);
        }
        echo '</div>';
        echo '<div class="sq-list-add-row"><button type="button" class="button" id="sq_add_vector">+ Add Vector</button></div>';
        echo '</div>';
    }

    private function render_vector_row($vi, $v, $is_template = false) {
        $key        = $v['key']        ?? '';
        $label      = $v['label']      ?? '';
        $type       = $v['type']       ?? 'unidirectional';
        $low_label  = $v['low_label']  ?? '';
        $high_label = $v['high_label'] ?? '';
        $bi_hidden  = ($type !== 'bidirectional') ? ' style="display:none"' : '';

        echo '<div class="sq-vector-row" data-vindex="' . esc_attr($vi) . '">';
        echo '<span class="sq-drag-handle">⠿</span>';
        echo '<div class="sq-item-toggle">';

        // Contracted header
        echo '<div class="sq-item-header">';
        echo '<span class="sq-summary-title">' . esc_html($label ?: 'New vector') . '</span>';
        echo '<span class="sq-chevron">&#9654;</span>';
        echo '</div>';

        // Expanded body
        echo '<div class="sq-item-body">';

        // Hidden key (auto-generated from label by JS)
        echo '<input type="hidden" class="sq-vec-key" name="vectors[' . esc_attr($vi) . '][key]" value="' . esc_attr($key) . '" />';

        // Main inline row: label | type | delete
        echo '<div class="sq-vector-main">';
        echo '<input type="text" class="sq-vec-label" name="vectors[' . esc_attr($vi) . '][label]" value="' . esc_attr($label) . '" placeholder="Vector name (e.g. Motivation)" />';
        echo '<select class="sq-vec-type" name="vectors[' . esc_attr($vi) . '][type]">';
        echo '<option value="unidirectional"' . selected($type, 'unidirectional', false) . '>Unidirectional (0→1)</option>';
        echo '<option value="bidirectional"' . selected($type, 'bidirectional', false) . '>Bidirectional (−1→+1)</option>';
        echo '</select>';
        echo '<button type="button" class="button-link-delete sq_delete_vector">Delete</button>';
        echo '<button type="button" class="sq-item-collapse" title="Collapse">&#9650;</button>';
        echo '</div>';

        // Second row: direction labels (bidirectional only)
        echo '<div class="sq-vec-bi-labels"' . $bi_hidden . '>';
        echo '<input type="text" class="sq-vec-low" name="vectors[' . esc_attr($vi) . '][low_label]" value="' . esc_attr($low_label) . '" placeholder="−1 end (e.g. Contribution)" />';
        echo '<span class="sq-vec-bi-arrow">→</span>';
        echo '<input type="text" class="sq-vec-high" name="vectors[' . esc_attr($vi) . '][high_label]" value="' . esc_attr($high_label) . '" placeholder="+1 end (e.g. Expression)" />';
        echo '</div>';

        echo '</div>'; // item-body
        echo '</div>'; // item-toggle
        echo '</div>'; // vector-row
    }

    // ---------------------------------------------------------------
    // Result categories card (catset tabs + category list)

    private function render_categories_card($categories, $catsets, $vectors) {
        // Group categories by set key for display ordering
        echo '<div class="slickquiz-card">';
        echo '<h2>Result Categories</h2>';

        // Tab strip
        echo '<div class="sq-catset-strip">';
        echo '<div class="sq-catset-tabs" id="sq_category_tabs">';
        foreach ($catsets as $si => $s) {
            $this->render_catset_tab($si, $s);
        }
        echo '</div>';
        echo '<button type="button" class="button sq-catset-add-btn" id="sq_add_catset">+ Add Set</button>';
        echo '</div>';

        // Category panel
        echo '<div class="sq-catset-panel">';
        echo '<div id="sq_categories">';
        foreach ($categories as $ci => $cat) {
            $this->render_category_block($ci, $cat, $vectors);
        }
        echo '</div>';
        echo '<div class="sq-list-add-row"><button type="button" class="button" id="sq_add_category">+ Add Category</button></div>';
        echo '</div>';

        echo '</div>';
    }

    private function render_catset_tab($si, $s) {
        $key   = $s['key']   ?? '';
        $label = $s['label'] ?? '';

        echo '<div class="sq-catset-tab" data-sindex="' . esc_attr($si) . '" data-setkey="' . esc_attr($key) . '">';
        echo '<input type="hidden" class="sq-catset-key" name="category_sets[' . esc_attr($si) . '][key]" value="' . esc_attr($key) . '" />';
        echo '<input type="text" class="sq-catset-tab-input" name="category_sets[' . esc_attr($si) . '][label]" value="' . esc_attr($label) . '" placeholder="Set name" />';
        echo '<button type="button" class="sq-catset-tab-delete" aria-label="Delete set">&times;</button>';
        echo '</div>';
    }

    private function render_category_block($ci, $cat, $vectors, $is_template = false) {
        $cat_id  = (int)($cat['id']                  ?? 0);
        $title   = $cat['title']                      ?? '';
        $desc    = $cat['description']                ?? '';
        $set_key = $cat['category_set_key']           ?? '';
        $att_id  = (int)($cat['image_attachment_id']  ?? 0);
        $scores  = json_decode($cat['scores_json']    ?? '{}', true) ?: [];
        $img     = $att_id ? wp_get_attachment_image_src($att_id, 'thumbnail') : null;
        $img_url = $img ? $img[0] : '';

        echo '<div class="slickquiz-category" data-catindex="' . esc_attr($ci) . '" data-setkey="' . esc_attr($set_key) . '">';
        echo '<span class="sq-drag-handle">⠿</span>';
        echo '<div class="sq-item-toggle">';

        // Contracted header
        echo '<div class="sq-item-header">';
        echo '<span class="sq-summary-title">' . esc_html($title ?: 'New category') . '</span>';
        echo '<span class="sq-chevron">&#9654;</span>';
        echo '</div>';

        // Expanded body
        echo '<div class="sq-item-body">';

        echo '<input type="hidden" name="categories[' . esc_attr($ci) . '][id]" value="' . intval($cat_id) . '" />';
        echo '<input type="hidden" class="sq-cat-setkey" name="categories[' . esc_attr($ci) . '][category_set_key]" value="' . esc_attr($set_key) . '" />';

        echo '<div class="sq-cat-delete-row">';
        echo '<button type="button" class="sq-item-collapse" title="Collapse">&#9650;</button>';
        echo '<button type="button" class="button-link-delete sq_delete_category">Delete</button>';
        echo '</div>';

        echo '<div class="sq-two-col">';

        // Left: title, description, image
        echo '<div class="sq-col-left">';
        echo '<label class="slickquiz-label">Title</label>';
        echo '<input class="regular-text sq-cat-title-input" type="text" name="categories[' . esc_attr($ci) . '][title]" value="' . esc_attr($title) . '" placeholder="Category title" />';
        echo '<label class="slickquiz-label">Description</label>';
        echo '<textarea name="categories[' . esc_attr($ci) . '][description]" rows="3" class="large-text">' . esc_textarea($desc) . '</textarea>';
        echo '<input type="hidden" class="sq_cat_image_attachment_id" name="categories[' . esc_attr($ci) . '][image_attachment_id]" value="' . intval($att_id) . '" />';
        echo '<div class="slickquiz-row" style="margin-top:8px;">';
        echo '<button type="button" class="button sq_pick_cat_image">Select image</button>';
        echo '<button type="button" class="button sq_clear_cat_image">Clear</button>';
        echo '</div>';
        echo '<div class="sq_cat_thumb">';
        if ($img_url) {
            echo '<img src="' . esc_url($img_url) . '" alt="" />';
        } else {
            echo '<div class="sq_thumb_empty">No image</div>';
        }
        echo '</div>';
        echo '</div>'; // col-left

        // Right: score sliders
        echo '<div class="sq-col-right">';
        echo '<div class="sq_scores" data-scores="' . esc_attr(wp_json_encode($scores)) . '"></div>';
        echo '</div>';

        echo '</div>'; // two-col
        echo '</div>'; // item-body
        echo '</div>'; // item-toggle
        echo '</div>'; // category
    }

    // ---------------------------------------------------------------
    // Questions / options

    private function render_question_block($qi, $q, $vectors = [], $is_template = false) {
        $q_title = $q['title'] ?? '';
        $q_type  = $q['type']  ?? 'select_2';
        $options = $q['options'] ?? [];
        if (empty($options)) {
            $options = [
                ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
                ['label' => '', 'image_attachment_id' => 0, 'config_json' => null],
            ];
        }
        $q_config        = json_decode($q['config_json'] ?? '{}', true) ?: [];
        $show_info_after = !empty($q_config['show_info_after']);
        $q_classes       = 'slickquiz-question' . ($show_info_after ? ' sq-has-info-after' : '');

        echo '<div class="' . esc_attr($q_classes) . '" data-qindex="' . esc_attr($qi) . '">';
        echo '<span class="sq-drag-handle">⠿</span>';
        echo '<div class="sq-item-toggle">';

        // Contracted header (always visible)
        echo '<div class="sq-item-header">';
        echo '<div class="sq-item-summary">';
        echo '<div class="sq-summary-title">' . esc_html($q_title ?: 'New question') . '</div>';
        echo '<ul class="sq-summary-opts">';
        foreach ($options as $opt) {
            echo '<li>' . esc_html(($opt['label'] ?? '') ?: '—') . '</li>';
        }
        echo '</ul>';
        echo '</div>';
        echo '<span class="sq-chevron">&#9654;</span>';
        echo '</div>';

        // Expanded body
        echo '<div class="sq-item-body">';

        // Inline edit row: title | type | info-after checkbox | delete
        echo '<div class="sq-question-header">';
        echo '<input class="sq-question-title-input" type="text" name="questions[' . esc_attr($qi) . '][title]" value="' . esc_attr($q_title) . '" placeholder="Question" required />';
        echo '<select name="questions[' . esc_attr($qi) . '][type]" class="sq_qtype">';
        foreach (['select_2' => 'Select 2', 'select_3' => 'Select 3', 'select_4' => 'Select 4', 'slider' => 'Slider', 'info' => 'Info'] as $val => $lbl) {
            echo '<option value="' . esc_attr($val) . '"' . selected($q_type, $val, false) . '>' . esc_html($lbl) . '</option>';
        }
        echo '</select>';
        echo '<label class="sq-info-after-label">';
        echo '<input type="checkbox" class="sq-info-after-toggle" name="questions[' . esc_attr($qi) . '][show_info_after]" value="1"' . checked($show_info_after, true, false) . ' />';
        echo ' Info after</label>';
        echo '<button type="button" class="button-link-delete sq_delete_question">Delete</button>';
        echo '<button type="button" class="sq-item-collapse" title="Collapse">&#9650;</button>';
        echo '</div>';

        // Options
        echo '<div class="sq-options-section">';
        echo '<div class="slickquiz-row slickquiz-row-between" style="margin-top:10px;">';
        echo '<h4 style="margin:0;">Options</h4>';
        echo '<button type="button" class="button sq_add_option">+ Add Option</button>';
        echo '</div>';
        echo '<div class="sq_options">';
        foreach ($options as $oi => $opt) {
            $this->render_option_block($qi, $oi, $opt, $vectors, $is_template);
        }
        echo '</div>';
        echo '</div>';

        echo '</div>'; // item-body
        echo '</div>'; // item-toggle
        echo '</div>'; // question
    }

    private function render_option_block($qi, $oi, $opt, $vectors = [], $is_template = false) {
        $label   = $opt['label']               ?? '';
        $att_id  = (int)($opt['image_attachment_id'] ?? 0);
        $img     = $att_id ? wp_get_attachment_image_src($att_id, 'thumbnail') : null;
        $img_url = $img ? $img[0] : '';
        $scores  = [];
        $info_att_id  = 0;
        $info_message = '';
        if (!empty($opt['config_json'])) {
            $cfg          = json_decode($opt['config_json'], true);
            $scores       = $cfg['scores'] ?? [];
            $info_att_id  = (int)($cfg['info_image_attachment_id'] ?? 0);
            $info_message = (string)($cfg['info_message'] ?? '');
        }
        $info_img     = $info_att_id ? wp_get_attachment_image_src($info_att_id, 'thumbnail') : null;
        $info_img_url = $info_img ? $info_img[0] : '';

        echo '<div class="slickquiz-option" data-oindex="' . esc_attr($oi) . '">';
        echo '<span class="sq-drag-handle">⠿</span>';
        echo '<div class="sq-item-toggle">';

        // Contracted header
        echo '<div class="sq-item-header">';
        echo '<span class="sq-summary-title">' . esc_html($label ?: 'New option') . '</span>';
        echo '<span class="sq-chevron">&#9654;</span>';
        echo '</div>';

        // Expanded body
        echo '<div class="sq-item-body">';

        // Label input inline with delete button
        echo '<div class="sq-opt-delete-row">';
        echo '<input class="sq-opt-label-input" type="text" name="questions[' . esc_attr($qi) . '][options][' . esc_attr($oi) . '][label]" value="' . esc_attr($label) . '" placeholder="Option label" required />';
        echo '<button type="button" class="button-link-delete sq_delete_option">Delete</button>';
        echo '<button type="button" class="sq-item-collapse" title="Collapse">&#9650;</button>';
        echo '</div>';

        echo '<div class="sq-two-col">';

        // Left: image
        echo '<div class="sq-col-left">';
        echo '<input type="hidden" class="sq_image_attachment_id" name="questions[' . esc_attr($qi) . '][options][' . esc_attr($oi) . '][image_attachment_id]" value="' . intval($att_id) . '" />';
        echo '<div class="slickquiz-row" style="margin-top:8px;">';
        echo '<button type="button" class="button sq_pick_image">Select image</button>';
        echo '<button type="button" class="button sq_clear_image">Clear</button>';
        echo '</div>';
        echo '<div class="sq_thumb">';
        if ($img_url) {
            echo '<img src="' . esc_url($img_url) . '" alt="" />';
        } else {
            echo '<div class="sq_thumb_empty">No image</div>';
        }
        echo '</div>';
        echo '</div>'; // col-left

        // Right: score sliders
        echo '<div class="sq-col-right">';
        echo '<div class="sq_scores" data-scores="' . esc_attr(wp_json_encode($scores)) . '"></div>';
        echo '</div>';

        echo '</div>'; // two-col

        // Info screen section (visible only when parent question has sq-has-info-after)
        echo '<div class="sq-opt-info-section">';
        echo '<div class="slickquiz-divider"></div>';
        echo '<p class="sq-opt-info-label">Info screen after selection</p>';
        echo '<div class="sq-two-col">';

        echo '<div class="sq-col-left">';
        echo '<input type="hidden" class="sq_info_image_attachment_id" name="questions[' . esc_attr($qi) . '][options][' . esc_attr($oi) . '][info_image_attachment_id]" value="' . intval($info_att_id) . '" />';
        echo '<div class="slickquiz-row" style="margin-top:4px;">';
        echo '<button type="button" class="button sq_pick_info_image">Select image</button>';
        echo '<button type="button" class="button sq_clear_info_image">Clear</button>';
        echo '</div>';
        echo '<div class="sq_info_thumb">';
        if ($info_img_url) {
            echo '<img src="' . esc_url($info_img_url) . '" alt="" />';
        } else {
            echo '<div class="sq_thumb_empty">No image</div>';
        }
        echo '</div>';
        echo '</div>'; // col-left

        echo '<div class="sq-col-right">';
        echo '<label class="slickquiz-label" style="margin-top:0;">Message</label>';
        echo '<input class="large-text" type="text" name="questions[' . esc_attr($qi) . '][options][' . esc_attr($oi) . '][info_message]" value="' . esc_attr($info_message) . '" placeholder="Info message text" />';
        echo '</div>'; // col-right

        echo '</div>'; // two-col
        echo '</div>'; // sq-opt-info-section

        echo '</div>'; // item-body
        echo '</div>'; // item-toggle
        echo '</div>'; // option
    }

    // ---------------------------------------------------------------
    // Responses page

    public function render_responses_page() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
        if (!$quiz_id) wp_die('Missing quiz_id');
        $quiz = SlickQuiz_QuizRepo::get_quiz($quiz_id);
        if (!$quiz) wp_die('Quiz not found');

        $bundle             = SlickQuiz_QuizRepo::list_attempts_with_answers_for_quiz($quiz_id);
        $attempts           = $bundle['attempts'];
        $answers_by_attempt = $bundle['answers'];
        $results_by_attempt = $bundle['results'];
        $questions          = $quiz['questions'] ?? [];
        $question_cols      = 0;
        foreach ($questions as $q) $question_cols += (($q['type'] ?? '') === 'slider') ? 2 : 1;

        $back_url = admin_url('admin.php?page=' . self::MENU_SLUG);
        $csv_url  = wp_nonce_url(admin_url('admin-post.php?action=slickquiz_export_csv&quiz_id=' . $quiz_id), 'slickquiz_export_csv', 'sq_csv_nonce');

        echo '<div class="wrap slickquiz">';
        echo '<h1>Responses: ' . esc_html($quiz['title']) . '</h1>';
        echo '<p><a href="' . esc_url($back_url) . '">&larr; Back</a> <a class="button button-primary" href="' . esc_url($csv_url) . '">Download CSV</a></p>';
        echo '<div style="overflow:auto;border:1px solid #dcdcde;border-radius:10px;background:#fff;">';
        echo '<table class="widefat striped" style="min-width:1100px;">';
        echo '<thead><tr><th>Attempt ID</th><th>User</th><th>Started</th><th>Completed</th>';
        foreach ($questions as $q) {
            $label = $q['title'] ?: ('Q' . (int)($q['position'] ?? $q['id']));
            if (($q['type'] ?? '') === 'slider') {
                echo '<th>' . esc_html($label . ' (pick)') . '</th><th>' . esc_html($label . ' (strength)') . '</th>';
            } else {
                echo '<th>' . esc_html($label) . '</th>';
            }
        }
        echo '<th>Result JSON</th></tr></thead><tbody>';

        if (empty($attempts)) {
            echo '<tr><td colspan="' . (5 + $question_cols) . '">No responses yet.</td></tr>';
        } else {
            foreach ($attempts as $a) {
                $aid  = (int)$a['id'];
                $user = $a['user_login'] ?: ((int)$a['user_id'] ? '#' . (int)$a['user_id'] : 'Unregistered');
                echo '<tr><td>' . esc_html($aid) . '</td><td>' . esc_html($user) . '</td>';
                echo '<td>' . esc_html($a['started_at']) . '</td><td>' . esc_html($a['completed_at'] ?: '') . '</td>';
                foreach ($questions as $q) {
                    $qid = (int)$q['id'];
                    $ans_json = $answers_by_attempt[$aid][$qid] ?? null;
                    if (($q['type'] ?? '') === 'slider') {
                        $pick = ''; $strength = '';
                        if ($ans_json) {
                            $decoded = json_decode($ans_json, true);
                            $v = (int)($decoded['value'] ?? 0);
                            $strength = (string)abs($v);
                            if ($v < 0) $pick = (string)(($q['options'][0]['label'] ?? '') ?: 'left');
                            elseif ($v > 0) $pick = (string)(($q['options'][1]['label'] ?? '') ?: 'right');
                            else { $pick = ''; $strength = '0'; }
                        }
                        echo '<td>' . esc_html($pick) . '</td><td>' . esc_html($strength) . '</td>';
                        continue;
                    }
                    $cell = '';
                    if ($ans_json) {
                        $decoded = json_decode($ans_json, true);
                        $oid = $decoded['option_id'] ?? null;
                        if ($oid) {
                            foreach (($q['options'] ?? []) as $opt) {
                                if ((int)$opt['id'] === (int)$oid) { $cell = (string)$opt['label']; break; }
                            }
                            if ($cell === '') $cell = 'option_id:' . (int)$oid;
                        }
                    }
                    echo '<td>' . esc_html($cell) . '</td>';
                }
                echo '<td><code style="white-space:pre-wrap;">' . esc_html(substr($results_by_attempt[$aid] ?? '', 0, 500)) . '</code></td>';
                echo '</tr>';
            }
        }
        echo '</tbody></table></div></div>';
    }

    // ---------------------------------------------------------------
    // Save handler

    public function handle_save_quiz() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        if (!isset($_POST['slickquiz_nonce']) || !wp_verify_nonce($_POST['slickquiz_nonce'], 'slickquiz_save_quiz')) wp_die('Bad nonce');

        // wp_magic_quotes adds slashes to $_POST; strip them first on the whole array
        $post = wp_unslash($_POST);

        $quiz_id = isset($post['quiz_id']) ? intval($post['quiz_id']) : 0;
        $title   = isset($post['title'])   ? sanitize_text_field($post['title']) : '';
        $slug    = isset($post['slug'])    ? sanitize_title($post['slug']) : '';
        if ($title === '') wp_die('Title required');
        if ($slug  === '') $slug = sanitize_title($title);

        $results_module_js = $post['results_module_js'] ?? '';
        // Basic safety: strip PHP tags; JS content is admin-only and not user-facing in raw form
        $results_module_js = preg_replace('/<\?.*?\?>/s', '', $results_module_js);

        $vectors   = $this->sanitize_vectors($post['vectors'] ?? []);
        $catsets   = $this->sanitize_category_sets($post['category_sets'] ?? []);
        $meta_json = wp_json_encode(['scoring_vectors' => $vectors, 'category_sets' => $catsets]);

        $vector_keys        = array_column($vectors, 'key');
        $questions_payload  = $this->sanitize_questions_payload($post['questions'] ?? [], $vector_keys);
        $categories_payload = $this->sanitize_categories($post['categories'] ?? [], $vector_keys);

        if (!$quiz_id) {
            $quiz_id = SlickQuiz_QuizRepo::create_quiz($title, $slug, $results_module_js, $meta_json);
        } else {
            SlickQuiz_QuizRepo::update_quiz($quiz_id, $title, $slug, $results_module_js, $meta_json);
        }

        SlickQuiz_QuizRepo::replace_questions_and_options($quiz_id, $questions_payload);
        SlickQuiz_QuizRepo::replace_categories($quiz_id, $categories_payload);

        wp_safe_redirect(admin_url('admin.php?page=' . self::MENU_SLUG . '&saved=1'));
        exit;
    }

    // ---------------------------------------------------------------
    // CSV export

    public function handle_export_csv() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        if (!isset($_GET['sq_csv_nonce']) || !wp_verify_nonce($_GET['sq_csv_nonce'], 'slickquiz_export_csv')) wp_die('Bad nonce');
        $quiz_id = isset($_GET['quiz_id']) ? intval($_GET['quiz_id']) : 0;
        if (!$quiz_id) wp_die('Missing quiz_id');
        $quiz = SlickQuiz_QuizRepo::get_quiz($quiz_id);
        if (!$quiz) wp_die('Quiz not found');

        $bundle             = SlickQuiz_QuizRepo::list_attempts_with_answers_for_quiz($quiz_id);
        $attempts           = $bundle['attempts'];
        $answers_by_attempt = $bundle['answers'];
        $results_by_attempt = $bundle['results'];
        $questions          = $quiz['questions'] ?? [];

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=slickquiz-' . sanitize_title($quiz['slug'] ?: $quiz['title']) . '-responses.csv');

        $out    = fopen('php://output', 'w');
        $header = ['attempt_id','user','started_at','completed_at'];
        foreach ($questions as $q) {
            $label = $q['title'] ?: ('Q' . (int)$q['id']);
            if (($q['type'] ?? '') === 'slider') { $header[] = $label . ' (pick)'; $header[] = $label . ' (strength)'; }
            else $header[] = $label;
        }
        $header[] = 'result_json';
        fputcsv($out, $header);

        foreach ($attempts as $a) {
            $aid  = (int)$a['id'];
            $row  = [$aid, $a['user_login'] ?: ('#' . (int)$a['user_id']), $a['started_at'], $a['completed_at'] ?: ''];
            foreach ($questions as $q) {
                $qid = (int)$q['id'];
                $ans_json = $answers_by_attempt[$aid][$qid] ?? null;
                if (($q['type'] ?? '') === 'slider') {
                    $pick = ''; $strength = '';
                    if ($ans_json) {
                        $decoded = json_decode($ans_json, true);
                        $v = (int)($decoded['value'] ?? 0);
                        $strength = (string)abs($v);
                        if ($v < 0) $pick = (string)(($q['options'][0]['label'] ?? '') ?: 'left');
                        elseif ($v > 0) $pick = (string)(($q['options'][1]['label'] ?? '') ?: 'right');
                        else { $pick = ''; $strength = '0'; }
                    }
                    $row[] = $pick; $row[] = $strength; continue;
                }
                $cell = '';
                if ($ans_json) {
                    $decoded = json_decode($ans_json, true);
                    $oid = $decoded['option_id'] ?? null;
                    if ($oid) {
                        foreach (($q['options'] ?? []) as $opt) {
                            if ((int)$opt['id'] === (int)$oid) { $cell = (string)$opt['label']; break; }
                        }
                        if ($cell === '') $cell = 'option_id:' . (int)$oid;
                    }
                }
                $row[] = $cell;
            }
            $row[] = $results_by_attempt[$aid] ?? '';
            fputcsv($out, $row);
        }
        fclose($out); exit;
    }

    // ---------------------------------------------------------------
    // Sanitization

    private function sanitize_vectors($raw) {
        $out = [];
        foreach ((array)$raw as $v) {
            $key   = sanitize_key($v['key']   ?? '');
            $label = sanitize_text_field($v['label'] ?? '');
            $type  = in_array($v['type'] ?? '', ['unidirectional','bidirectional'], true) ? $v['type'] : 'unidirectional';
            if (!$key || !$label) continue;
            $item = ['key' => $key, 'label' => $label, 'type' => $type];
            if ($type === 'bidirectional') {
                $item['low_label']  = sanitize_text_field($v['low_label']  ?? '');
                $item['high_label'] = sanitize_text_field($v['high_label'] ?? '');
            }
            $out[] = $item;
        }
        return $out;
    }

    private function sanitize_category_sets($raw) {
        $out = [];
        foreach ((array)$raw as $s) {
            $key   = sanitize_key($s['key']   ?? '');
            $label = sanitize_text_field($s['label'] ?? '');
            if (!$key || !$label) continue;
            $out[] = ['key' => $key, 'label' => $label];
        }
        return $out;
    }

    private function sanitize_categories($raw, $vector_keys) {
        $out = []; $pos = 0;
        foreach ((array)$raw as $c) {
            $title   = sanitize_text_field($c['title']            ?? '');
            $desc    = sanitize_textarea_field($c['description']  ?? '');
            $set_key = sanitize_key($c['category_set_key']        ?? '');
            $att_id  = (int)($c['image_attachment_id']            ?? 0);
            $id      = (int)($c['id']                             ?? 0);
            if (!$title && !$desc && !$att_id) continue;
            $scores = [];
            foreach ($vector_keys as $vk) {
                $val = isset($c['scores'][$vk]) ? (float)$c['scores'][$vk] : 0.0;
                $scores[$vk] = round(max(-1.0, min(1.0, $val)), 4);
            }
            $out[] = ['id' => $id, 'title' => $title, 'description' => $desc,
                      'category_set_key' => $set_key, 'image_attachment_id' => $att_id,
                      'position' => $pos++, 'scores' => $scores];
        }
        return $out;
    }

    private function sanitize_questions_payload($raw_questions, $vector_keys = []) {
        $out = []; $allowed_types = ['select_2','select_3','select_4','slider','info'];
        foreach ((array)$raw_questions as $q) {
            $title           = sanitize_text_field($q['title'] ?? '');
            $type            = sanitize_text_field($q['type']  ?? 'select_2');
            $show_info_after = !empty($q['show_info_after']);
            if (!in_array($type, $allowed_types, true)) $type = 'select_2';
            $opts = [];
            foreach ((array)($q['options'] ?? []) as $o) {
                $label        = sanitize_text_field($o['label'] ?? '');
                $att_id       = isset($o['image_attachment_id']) ? intval($o['image_attachment_id']) : 0;
                $info_att_id  = isset($o['info_image_attachment_id']) ? intval($o['info_image_attachment_id']) : 0;
                $info_message = sanitize_text_field($o['info_message'] ?? '');
                if ($label === '' && !$att_id) continue;
                $scores = [];
                foreach ($vector_keys as $vk) {
                    $val = isset($o['scores'][$vk]) ? (float)$o['scores'][$vk] : 0.0;
                    $scores[$vk] = round(max(-1.0, min(1.0, $val)), 4);
                }
                $opts[] = ['label' => $label, 'image_attachment_id' => $att_id, 'scores' => $scores,
                           'info_image_attachment_id' => $info_att_id, 'info_message' => $info_message];
            }
            $min = 2; $max = 4;
            if ($type === 'select_2') { $min = 2; $max = 2; }
            if ($type === 'select_3') { $min = 3; $max = 3; }
            if ($type === 'select_4') { $min = 4; $max = 4; }
            if ($type === 'slider')   { $min = 2; $max = 2; }
            if ($type === 'info')     { $min = 1; $max = 1; }
            while (count($opts) < $min) $opts[] = ['label' => '', 'image_attachment_id' => 0, 'scores' => [],
                                                    'info_image_attachment_id' => 0, 'info_message' => ''];
            if (count($opts) > $max) $opts = array_slice($opts, 0, $max);
            $out[] = ['title' => $title, 'type' => $type, 'show_info_after' => $show_info_after, 'options' => $opts];
        }
        if (empty($out)) $out[] = ['title' => '', 'type' => 'select_2', 'show_info_after' => false,
            'options' => [['label'=>'','image_attachment_id'=>0,'scores'=>[],'info_image_attachment_id'=>0,'info_message'=>''],
                          ['label'=>'','image_attachment_id'=>0,'scores'=>[],'info_image_attachment_id'=>0,'info_message'=>'']]];
        return $out;
    }
}
