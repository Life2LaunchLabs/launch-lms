<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_PublicRoutes {

    const QVAR = 'slickquiz_slug';
    const RVAR = 'slickquiz_results_slug';

    public function __construct() {
        add_action('init', [$this, 'add_rewrite_rules']);
        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('template_redirect', [$this, 'handle_route']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
    }

    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^quiz/([^/]+)/results/?$',
            'index.php?' . self::RVAR . '=$matches[1]',
            'top'
        );
        add_rewrite_rule(
            '^quiz/([^/]+)/?$',
            'index.php?' . self::QVAR . '=$matches[1]',
            'top'
        );
    }

    public function add_query_vars($vars) {
        $vars[] = self::QVAR;
        $vars[] = self::RVAR;
        return $vars;
    }

    public function register_assets() {
        wp_register_style('slickquiz-public', SLICKQUIZ_URL . 'assets/public.css', [], SLICKQUIZ_VERSION);
        wp_register_script('slickquiz-public', SLICKQUIZ_URL . 'assets/public.js', [], SLICKQUIZ_VERSION, true);
        wp_register_style('slickquiz-material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', [], null);
    }

    public function handle_route() {
        $results_slug = get_query_var(self::RVAR);
        if ($results_slug) {
            $this->handle_results_route($results_slug);
            return;
        }

        $slug = get_query_var(self::QVAR);
        if (!$slug) return;

        // We are handling this request. Render our own page.
        status_header(200);
        nocache_headers();

        $quiz = SlickQuiz_QuizRepo::get_quiz_by_slug($slug);
        if (!$quiz) {
            $this->render_simple_page('Quiz not found', '<p>This quiz does not exist.</p>', 404);
            exit;
        }

        // Render quiz shell + payload
        $payload = $this->build_quiz_payload($quiz);

        wp_enqueue_style('slickquiz-public');
        wp_enqueue_style('slickquiz-material-icons');
        wp_enqueue_script('slickquiz-public');

        // Inline results module JS if set
        $module_js = $quiz['results_module_js'] ?? '';
        if ($module_js) {
            wp_add_inline_script('slickquiz-public', $module_js);
        }

        // wp_localize_script('slickquiz-public', 'SlickQuizCfg', [
        //     'restUrl' => esc_url_raw(rest_url('slickquiz/v1')),
        //     'nonce'   => wp_create_nonce('wp_rest'),
        // ]);

        $root = $this->render_quiz_root($payload);

        $this->render_quiz_shell($quiz['title'], $root, true);
        exit;
    }

    private function handle_results_route($slug) {
        status_header(200);
        nocache_headers();

        $quiz = SlickQuiz_QuizRepo::get_quiz_by_slug($slug);
        if (!$quiz) {
            $this->render_simple_page('Quiz not found', '<p>This quiz does not exist.</p>', 404);
            exit;
        }

        wp_enqueue_style('slickquiz-public');

        $deps      = [];
        $module_js = $quiz['results_module_js'] ?? '';
        if ($module_js) {
            wp_register_script('slickquiz-results-module', false, [], false, true);
            wp_enqueue_script('slickquiz-results-module');
            wp_add_inline_script('slickquiz-results-module', $module_js);
            $deps[] = 'slickquiz-results-module';
        }

        // Inline init: read sessionStorage and render results
        $init_js = '(function(){
            var raw=sessionStorage.getItem("sq_results");
            if(!raw){window.location.replace(' . wp_json_encode(home_url('/quiz/' . rawurlencode($slug) . '/')) . ');return;}
            var d=JSON.parse(raw);
            sessionStorage.removeItem("sq_results");
            var el=document.getElementById("sq-results");
            var mod=window.SlickQuizResults;
            if(mod&&typeof mod.renderResults==="function"){
                mod.renderResults(el,d.resultBundle,d.payload,d.answersPayload);
            }else{
                el.innerHTML=\'<div style="padding:32px;text-align:center;"><h2>Recorded</h2><p style="opacity:.8;">Your response has been recorded.</p></div>\';
            }
        })();';

        wp_register_script('slickquiz-results-page', false, $deps, false, true);
        wp_enqueue_script('slickquiz-results-page');
        wp_add_inline_script('slickquiz-results-page', $init_js);

        $body = '
            <div style="min-height:100vh;background:#000;display:flex;justify-content:center;">
                <div id="sq-results" style="width:100%;min-height:100vh;background:#000;color:#fff;position:relative;overflow:auto;"></div>
            </div>
        ';

        $this->render_quiz_shell(esc_html($quiz['title']) . ' – Results', $body, true);
        exit;
    }

    private function build_quiz_payload($quiz) {
        $out = [
            'quiz' => [
                'id' => (int)$quiz['id'],
                'title' => (string)$quiz['title'],
                'slug' => (string)$quiz['slug'],
            ],
            'questions' => [],
        ];

        foreach (($quiz['questions'] ?? []) as $q) {
            $q_cfg = json_decode($q['config_json'] ?? '{}', true) ?: [];
            $qout = [
                'id'            => (int)$q['id'],
                'title'         => (string)$q['title'],
                'type'          => (string)$q['type'],
                'showInfoAfter' => !empty($q_cfg['show_info_after']),
                'options'       => [],
            ];

            foreach (($q['options'] ?? []) as $o) {
                $img_url = '';
                $att_id = (int)($o['image_attachment_id'] ?? 0);
                if ($att_id) {
                    $src = wp_get_attachment_image_src($att_id, 'large');
                    if ($src && !empty($src[0])) $img_url = $src[0];
                }

                $o_cfg        = json_decode($o['config_json'] ?? '{}', true) ?: [];
                $info_att_id  = (int)($o_cfg['info_image_attachment_id'] ?? 0);
                $info_img_url = '';
                if ($info_att_id) {
                    $src = wp_get_attachment_image_src($info_att_id, 'large');
                    if ($src && !empty($src[0])) $info_img_url = $src[0];
                }

                $qout['options'][] = [
                    'id'           => (int)$o['id'],
                    'label'        => (string)$o['label'],
                    'imageUrl'     => $img_url,
                    'infoImageUrl' => $info_img_url,
                    'infoMessage'  => (string)($o_cfg['info_message'] ?? ''),
                ];
            }

            $out['questions'][] = $qout;
        }

        return $out;
    }

    private function render_quiz_root($payload) {
        $json = wp_json_encode($payload);

        ob_start(); ?>
        <div class="sq-page">
        <div class="sq-viewport" data-quiz-id="<?php echo intval($payload['quiz']['id']); ?>">
            <!-- overlays (always above images) -->
            <div class="sq-header">
                <div class="sq-progress-row">
                    <button class="sq-back is-hidden" aria-label="Go to previous question"><span class="material-icons" aria-hidden="true">arrow_back</span></button>
                    <div class="sq-progress">
                        <div class="sq-progress-fill" style="width:0%"></div>
                    </div>
                </div>
                <div class="sq-title"></div>
            </div>

            <a class="sq-next" href="#" aria-disabled="true">Next</a>

            <!-- frames live beneath overlays -->
            <div class="sq-stack" aria-live="polite"></div>

            <script type="application/json" class="sq-payload"><?php echo $json; ?></script>
            <script>
                window.SlickQuizCfg = window.SlickQuizCfg || {};
                window.SlickQuizCfg.restUrl = <?php echo wp_json_encode(rest_url('slickquiz/v1')); ?>;
                window.SlickQuizCfg.nonce = <?php echo wp_json_encode(wp_create_nonce('wp_rest')); ?>;
                window.SlickQuizCfg.resultsUrl = <?php echo wp_json_encode(home_url('/quiz/' . rawurlencode($payload['quiz']['slug']) . '/results/')); ?>;
            </script>
        </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_quiz_shell($title, $body_html, $include_wp_head) {
        // Minimal template that still uses wp_head/wp_footer so scripts/styles enqueue correctly.
        // $include_wp_head true for real quiz; false is still safe (but we can keep it true always).
        ?>
        <!doctype html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html($title); ?></title>
            <?php wp_head(); ?>
        </head>
        <body <?php body_class('slickquiz-page'); ?>>
            <?php echo $body_html; ?>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
    }

    private function render_simple_page($title, $body_html, $status_code = 200) {
        status_header($status_code);
        wp_enqueue_style('slickquiz-public');
        $this->render_quiz_shell($title, '<div style="padding:24px;max-width:800px;margin:0 auto;">'.$body_html.'</div>', true);
    }
}