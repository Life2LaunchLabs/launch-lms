<?php
if (!defined('ABSPATH')) exit;

class SlickQuiz_Public {

    public function __construct() {
        add_shortcode('slickquiz', [$this, 'render_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
    }

    public function register_assets() {
        wp_register_style(
            'slickquiz-public',
            SLICKQUIZ_URL . 'assets/public.css',
            [],
            SLICKQUIZ_VERSION
        );

        wp_register_script(
            'slickquiz-public',
            SLICKQUIZ_URL . 'assets/public.js',
            [],
            SLICKQUIZ_VERSION,
            true
        );
    }

    public function render_shortcode($atts) {
        $atts = shortcode_atts([
            'id' => 0,
        ], $atts, 'slickquiz');

        $quiz_id = intval($atts['id']);
        if (!$quiz_id) {
            return '<div class="sq-error">Missing quiz id.</div>';
        }

        // Logged-in only
        if (!is_user_logged_in()) {
            $login_url = wp_login_url(get_permalink());
            $home_url = home_url('/');
            ob_start(); ?>
            <div class="sq-authgate">
                <div class="sq-authgate-card">
                    <h2>Login required</h2>
                    <p>You must be logged in to take this quiz.</p>
                    <div class="sq-authgate-actions">
                        <a class="sq-btn sq-btn-primary" href="<?php echo esc_url($login_url); ?>">Login</a>
                        <button class="sq-btn" type="button" onclick="history.back()">Back</button>
                        <a class="sq-btn sq-btn-link" href="<?php echo esc_url($home_url); ?>">Home</a>
                    </div>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        $quiz = SlickQuiz_QuizRepo::get_quiz($quiz_id);
        if (!$quiz) {
            return '<div class="sq-error">Quiz not found.</div>';
        }

        $payload = $this->build_quiz_payload($quiz);

        wp_enqueue_style('slickquiz-public');
        wp_enqueue_script('slickquiz-public');

        // Inline payload (simple v0)
        $json = wp_json_encode($payload);

        ob_start(); ?>
        <div class="sq-root" data-quiz-id="<?php echo intval($quiz_id); ?>">
            <div class="sq-progress">
                <div class="sq-progress-fill" style="width:0%"></div>
            </div>

            <a class="sq-next" href="#" aria-disabled="true">Next</a>

            <div class="sq-stack" id="sq-stack-<?php echo intval($quiz_id); ?>"></div>

            <script type="application/json" class="sq-payload"><?php echo $json; ?></script>
        </div>
        <?php
        return ob_get_clean();
    }

    private function build_quiz_payload($quiz) {
        $out = [
            'quiz' => [
                'id' => (int)$quiz['id'],
                'title' => (string)$quiz['title'],
                'slug' => (string)$quiz['slug'],
            ],
            'questions' => [],
        ];

        foreach (($quiz['questions'] ?? []) as $q) {
            $q_cfg = json_decode($q['config_json'] ?? '{}', true) ?: [];
            $qout = [
                'id'            => (int)$q['id'],
                'title'         => (string)$q['title'],
                'type'          => (string)$q['type'],
                'showInfoAfter' => !empty($q_cfg['show_info_after']),
                'options'       => [],
            ];

            foreach (($q['options'] ?? []) as $o) {
                $img_url = '';
                $att_id = (int)($o['image_attachment_id'] ?? 0);
                if ($att_id) {
                    $src = wp_get_attachment_image_src($att_id, 'large');
                    if ($src && !empty($src[0])) $img_url = $src[0];
                }

                $o_cfg        = json_decode($o['config_json'] ?? '{}', true) ?: [];
                $info_att_id  = (int)($o_cfg['info_image_attachment_id'] ?? 0);
                $info_img_url = '';
                if ($info_att_id) {
                    $src = wp_get_attachment_image_src($info_att_id, 'large');
                    if ($src && !empty($src[0])) $info_img_url = $src[0];
                }

                $qout['options'][] = [
                    'id'           => (int)$o['id'],
                    'label'        => (string)$o['label'],
                    'imageUrl'     => $img_url,
                    'infoImageUrl' => $info_img_url,
                    'infoMessage'  => (string)($o_cfg['info_message'] ?? ''),
                ];
            }

            $out['questions'][] = $qout;
        }

        return $out;
    }
}