(function () {
  function qs(el, sel) { return el.querySelector(sel); }
  function qsa(el, sel) { return Array.from(el.querySelectorAll(sel)); }

  function parsePayload(viewport) {
    const node = qs(viewport, ".sq-payload");
    if (!node) return null;
    try { return JSON.parse(node.textContent || "null"); } catch { return null; }
  }

  function optionLayoutFor(type) {
    if (type === "select_4") return "grid2x2";
    return "stack"; // select_2/select_3; slider overrides with slider2
  }

  function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }

  function buildFrames(viewport, payload) {
    const stack = qs(viewport, ".sq-stack");
    stack.innerHTML = "";

    payload.questions.forEach((q, idx) => {
      const frame = document.createElement("section");
      frame.className = "sq-frame";
      frame.dataset.index = String(idx);
      frame.dataset.qid = String(q.id);
      frame.dataset.type = q.type;

      if (q.type === "info") {
        const opt = q.options && q.options[0];
        const container = document.createElement("div");
        container.className = "sq-options info";
        if (opt && opt.imageUrl) {
          const img = document.createElement("img");
          img.src = opt.imageUrl;
          img.alt = opt.label || "";
          container.appendChild(img);
        }
        if (opt && opt.label) {
          const msg = document.createElement("div");
          msg.className = "sq-info-message";
          msg.textContent = opt.label;
          container.appendChild(msg);
        }
        frame.appendChild(container);
        stack.appendChild(frame);
        return;
      }

      const options = document.createElement("div");
      options.className = "sq-options " + optionLayoutFor(q.type);

      if (q.type === "slider") {
        options.classList.add("slider2"); // side-by-side

        q.options.slice(0, 2).forEach((opt) => {
          const pane = document.createElement("div");
          pane.className = "sq-opt sq-slider-pane";
          pane.dataset.oid = String(opt.id);
          pane.style.cursor = "default";
          pane.style.pointerEvents = "none"; // images not clickable

          if (opt.imageUrl) {
            const img = document.createElement("img");
            img.src = opt.imageUrl;
            img.alt = opt.label || "";
            pane.appendChild(img);
          }

          const label = document.createElement("div");
          label.className = "sq-opt-label";
          label.textContent = opt.label || "";
          pane.appendChild(label);

          options.appendChild(pane);
        });

        const sliderWrap = document.createElement("div");
        sliderWrap.className = "sq-slider";
        sliderWrap.innerHTML = `<input type="range" min="-100" max="100" value="0" step="1" aria-label="Slider answer" />`;
        frame.appendChild(sliderWrap);
      } else {
        q.options.forEach((opt) => {
          const btn = document.createElement("div");
          btn.className = "sq-opt";
          btn.dataset.oid = String(opt.id);

          if (opt.imageUrl) {
            const img = document.createElement("img");
            img.src = opt.imageUrl;
            img.alt = opt.label || "";
            btn.appendChild(img);
          }

          const label = document.createElement("div");
          label.className = "sq-opt-label";
          label.textContent = opt.label || "";
          btn.appendChild(label);

          options.appendChild(btn);
        });
      }

      frame.appendChild(options);
      stack.appendChild(frame);
    });
  }

  function hideTitle(viewport) {
    const t = qs(viewport, ".sq-title");
    if (!t) return;
    t.classList.remove("is-showing");
    t.classList.add("is-hiding");
  }

  function showTitle(viewport, text) {
    const t = qs(viewport, ".sq-title");
    if (!t) return;
    t.textContent = text || "";
    t.classList.remove("is-hiding");
    t.classList.remove("is-showing");
    void t.offsetWidth; // restart animation
    t.classList.add("is-showing");
  }

  function setProgress(viewport, activeIndex, total) {
    const fill = qs(viewport, ".sq-progress-fill");
    if (!fill) return;
    const pct = total <= 1 ? 100 : Math.round((activeIndex) / (total - 1) * 100);
    fill.style.width = pct + "%";
  }

  function setNextButton(viewport, visible, isLast) {
    const btn = qs(viewport, ".sq-next");
    if (!btn) return;
    btn.textContent = isLast ? "Done" : "Next";
    btn.classList.toggle("is-visible", !!visible);
    btn.setAttribute("aria-disabled", visible ? "false" : "true");
    btn.href = "#";
  }

  function showInfoOverlay(frame, imageUrl, message) {
    let ov = qs(frame, ".sq-info-overlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.className = "sq-info-overlay";
      frame.appendChild(ov);
    }
    ov.innerHTML = "";
    if (imageUrl) {
      const img = document.createElement("img");
      img.src = imageUrl;
      img.alt = "";
      ov.appendChild(img);
    }
    if (message) {
      const msg = document.createElement("div");
      msg.className = "sq-info-message";
      msg.textContent = message;
      ov.appendChild(msg);
    }
    void ov.offsetWidth; // force reflow before adding class
    ov.classList.add("is-visible");
  }

  function hideInfoOverlay(frame) {
    const ov = frame && qs(frame, ".sq-info-overlay");
    if (ov) ov.classList.remove("is-visible");
  }

  function animateStackTo(stack, fromY, toY, onDone) {
    const wrong = fromY + 18;
    const over = toY - 28;
    const anim = stack.animate(
      [
        { transform: `translate3d(0, ${fromY}px, 0)`, offset: 0 },
        { transform: `translate3d(0, ${wrong}px, 0)`, offset: 0.18 },
        { transform: `translate3d(0, ${over}px, 0)`, offset: 0.78 },
        { transform: `translate3d(0, ${toY}px, 0)`, offset: 1 },
      ],
      { duration: 520, easing: "cubic-bezier(.2, .9, .2, 1)", fill: "forwards" }
    );
    anim.onfinish = () => onDone && onDone();
  }

  function setOptionSelectionUI(frame, selectedOid) {
    const optionsWrap = qs(frame, ".sq-options");
    if (!optionsWrap) return;
    const opts = qsa(optionsWrap, ".sq-opt");

    opts.forEach((el) => {
      const isSel = selectedOid && el.dataset.oid === selectedOid;
      el.classList.toggle("is-selected", !!isSel);

      if (isSel) {
        el.classList.remove("sq-anim-unpop");
        el.classList.add("sq-anim-pop");
        setTimeout(() => el.classList.remove("sq-anim-pop"), 260);
      } else {
        el.classList.remove("sq-anim-pop");
        el.classList.add("sq-anim-unpop");
        setTimeout(() => el.classList.remove("sq-anim-unpop"), 160);
      }
    });

    optionsWrap.classList.toggle("has-selection", !!selectedOid);
  }

  function applySliderEffect(frame, value) {
    const panes = qsa(frame, ".sq-slider-pane");
    const v = clamp(Number(value || 0), -100, 100);
    const level = Math.abs(v) / 100;

    const leftActive = v < 0;
    const rightActive = v > 0;

    panes.forEach((p, idx) => {
      const isLeft = idx === 0;
      const isActive = (isLeft && leftActive) || (!isLeft && rightActive);

      const s = isActive ? (1 + 0.02 * level) : 1;
      p.style.transform = `scale(${s})`;
      p.style.boxShadow = isActive ? `0 10px 30px rgba(0,0,0,${0.25 + 0.2 * level})` : "none";
      p.style.outline = isActive ? `${Math.round(3 * level)}px solid rgba(255,255,255,${level})` : "0px solid transparent";

      if (!isActive && (leftActive || rightActive)) {
        p.style.filter = `grayscale(1) brightness(${1 - 0.45 * level})`;
      } else {
        p.style.filter = "none";
      }
    });
  }

  function setSliderTrackGradient(sliderEl, value) {
    const v = clamp(Number(value || 0), -100, 100);
    const p = ((v + 100) / 200) * 100; // 0..100, center=50
    let bg;

    if (v < 0) {
      bg = `linear-gradient(to right,
        rgba(255,255,255,0.25) 0%,
        rgba(255,255,255,0.25) ${p}%,
        rgba(255,0,0,0.9) ${p}%,
        rgba(255,0,0,0.9) 50%,
        rgba(255,255,255,0.25) 50%,
        rgba(255,255,255,0.25) 100%)`;
    } else if (v > 0) {
      bg = `linear-gradient(to right,
        rgba(255,255,255,0.25) 0%,
        rgba(255,255,255,0.25) 50%,
        rgba(0,140,255,0.9) 50%,
        rgba(0,140,255,0.9) ${p}%,
        rgba(255,255,255,0.25) ${p}%,
        rgba(255,255,255,0.25) 100%)`;
    } else {
      bg = `linear-gradient(to right,
        rgba(255,255,255,0.25) 0%,
        rgba(255,255,255,0.25) 100%)`;
    }

    sliderEl.style.background = bg;
  }

  function initQuiz(viewport) {
    const payload = parsePayload(viewport);
    if (!payload || !payload.questions) return;

    const stack = qs(viewport, ".sq-stack");
    const nextBtn = qs(viewport, ".sq-next");
    const total = payload.questions.length;

    const state = {
      activeIndex: 0,
      answers: {},          // qid -> oid OR {value}
      transitioning: false,
      currentTranslateY: 0,
      infoShowing: false,
    };
    state.attemptId = null;

    buildFrames(viewport, payload);

    const frames = () => qsa(stack, ".sq-frame");
    const activeFrame = () => frames()[state.activeIndex] || null;

    (async () => {
        try {
            const data = await apiPost("/attempts", { quiz_id: payload.quiz.id });
            state.attemptId = data.attempt_id;
        } catch (e) {
            // Non-fatal for UI, but saving will fail; you’ll see it in console.
            console.error("SlickQuiz: failed to create attempt", e);
        }
    })();

    // IMPORTANT: title update is separate from overlay update (prevents wiggle on option click)
    function setTitleForIndex(index) {
      const q = payload.questions[index];
      showTitle(viewport, (q && q.title) ? q.title : `Question ${index + 1}`);
    }

    function updateOverlay() {
      const f = activeFrame();
      if (!f) return;

      setProgress(viewport, state.activeIndex, total);

      const qid = f.dataset.qid;
      const isInfo = f.dataset.type === "info";
      const hasAnswer = isInfo || !!state.answers[qid];

      setNextButton(viewport, hasAnswer, state.activeIndex === total - 1);

      const backBtn = qs(viewport, ".sq-back");
      if (backBtn) backBtn.classList.toggle("is-hidden", state.activeIndex === 0);
    }

    function setInteractivityEnabled(enabled) {
      frames().forEach((f, idx) => {
        const isActive = idx === state.activeIndex;
        const options = qs(f, ".sq-options");
        if (options) options.style.pointerEvents = (enabled && isActive) ? "auto" : "none";

        const slider = qs(f, ".sq-slider input[type='range']");
        if (slider) slider.disabled = !(enabled && isActive);
      });
    }

    function gotoIndex(nextIndex) {
      if (state.transitioning) return;
      nextIndex = clamp(nextIndex, 0, total - 1);
      if (nextIndex === state.activeIndex) return;

      if (state.infoShowing) {
        state.infoShowing = false;
        hideInfoOverlay(activeFrame());
      }

      state.transitioning = true;
      setInteractivityEnabled(false);

      const from = state.currentTranslateY;
      const to = -nextIndex * window.innerHeight;

      animateStackTo(stack, from, to, () => {
        state.activeIndex = nextIndex;
        state.currentTranslateY = to;
        state.transitioning = false;

        setInteractivityEnabled(true);
        setTitleForIndex(state.activeIndex); // show/pop ONLY when question changes
        updateOverlay();
      });
    }

    async function apiPost(path, body) {
        const base = (window.SlickQuizCfg?.restUrl || "").replace(/\/+$/, "");
        const p = String(path || "").startsWith("/") ? path : "/" + path;

        const res = await fetch(base + p, {
            method: "POST",
            headers: {
            "Content-Type": "application/json",
            "X-WP-Nonce": window.SlickQuizCfg?.nonce || "",
            },
            credentials: "same-origin",
            body: JSON.stringify(body || {}),
        });
        if (!res.ok) {
            const txt = await res.text().catch(() => "");
            throw new Error(`API ${res.status}: ${txt || res.statusText}`);
        }
        return res.json();
    }

    function showSpinner() {
        // Minimal overlay
        let ov = viewport.querySelector(".sq-loading");
        if (!ov) {
            ov = document.createElement("div");
            ov.className = "sq-loading";
            ov.innerHTML = `<div class="sq-loading-inner"><div class="sq-spinner"></div><div class="sq-loading-text">Calculating results…</div></div>`;
            viewport.appendChild(ov);
        }
        ov.style.display = "grid";
    }

    function hideSpinner() {
        const ov = viewport.querySelector(".sq-loading");
        if (ov) ov.style.display = "none";
    }

    function renderDefaultResults() {
        viewport.innerHTML = `
            <div style="position:absolute;inset:0;display:grid;place-items:center;background:#000;color:#fff;padding:24px;text-align:center;">
            <div style="max-width:360px;">
                <h2 style="margin:0 0 10px 0;">Recorded</h2>
                <p style="margin:0;opacity:.85;">Your response has been recorded.</p>
            </div>
            </div>
        `;
    }

    function renderResults(resultBundle, answersPayload) {
        sessionStorage.setItem("sq_results", JSON.stringify({ resultBundle, payload, answersPayload }));
        window.location.href = window.SlickQuizCfg?.resultsUrl || ("/quiz/" + payload.quiz.slug + "/results/");
    }

    // Block scroll gestures, but allow touch-drag on the slider
    const block = (e) => {
      if (e.target.closest && e.target.closest(".sq-slider")) return;
      e.preventDefault();
    };
    viewport.addEventListener("wheel", block, { passive: false });
    viewport.addEventListener("touchmove", block, { passive: false });

    // Select clicks
    stack.addEventListener("click", (e) => {
      if (state.transitioning) return;
      const f = activeFrame();
      if (!f) return;
      if (f.dataset.type === "slider") return;

      const opt = e.target.closest(".sq-opt");
      if (!opt) return;

      if (opt.closest(".sq-frame") !== f) return;

      const qid = f.dataset.qid;
      const oid = opt.dataset.oid;

      const already = state.answers[qid] === oid;
      if (already) delete state.answers[qid];
      else state.answers[qid] = oid;

      setOptionSelectionUI(f, state.answers[qid] || null);
      updateOverlay();
    });

    // Slider setup
    frames().forEach((f) => {
      if (f.dataset.type !== "slider") return;

      const qid = f.dataset.qid;
      const slider = qs(f, ".sq-slider input[type='range']");
      if (!slider) return;

      state.answers[qid] = { value: 0 }; // counts as answered
      applySliderEffect(f, 0);
      setSliderTrackGradient(slider, 0);

      slider.addEventListener("input", () => {
        if (state.transitioning) return;
        const v = Number(slider.value || 0);
        state.answers[qid] = { value: v };
        applySliderEffect(f, v);
        setSliderTrackGradient(slider, v);
        updateOverlay();
      });

      const snapIfNeeded = () => {
        const v = Number(slider.value || 0);
        if (Math.abs(v) <= 20) { // your spec: ±20
          slider.value = "0";
          state.answers[qid] = { value: 0 };
          applySliderEffect(f, 0);
          setSliderTrackGradient(slider, 0);
          updateOverlay();
        }
      };

      slider.addEventListener("change", snapIfNeeded);
      slider.addEventListener("pointerup", snapIfNeeded);
      slider.addEventListener("touchend", snapIfNeeded);
    });

    // Back button
    const backBtn = qs(viewport, ".sq-back");
    if (backBtn) {
      backBtn.addEventListener("click", () => {
        if (state.transitioning) return;
        if (state.infoShowing) {
          state.infoShowing = false;
          hideInfoOverlay(activeFrame());
          return;
        }
        if (state.activeIndex === 0) return;
        backBtn.blur();
        hideTitle(viewport);
        gotoIndex(state.activeIndex - 1);
      });
    }

    // Next / Done
    nextBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      if (nextBtn.getAttribute("aria-disabled") === "true") return;
      if (state.transitioning) return;

      const f = activeFrame();
      const q = payload.questions[state.activeIndex];

      // If info overlay is showing, dismiss it and fall through to navigation
      if (state.infoShowing) {
        state.infoShowing = false;
        hideInfoOverlay(f);
        // fall through
      } else if (q && q.showInfoAfter) {
        // Maybe show the info overlay before navigating
        const qid = f ? f.dataset.qid : null;
        const oid = qid ? state.answers[qid] : null;
        if (oid) {
          const opt = q.options.find((o) => String(o.id) === oid);
          if (opt && (opt.infoImageUrl || opt.infoMessage)) {
            state.infoShowing = true;
            showInfoOverlay(f, opt.infoImageUrl, opt.infoMessage);
            return; // leave next button visible for the "proceed" click
          }
        }
      }

      nextBtn.classList.remove("is-visible");
      nextBtn.classList.add("is-hiding");
      setTimeout(() => nextBtn.classList.remove("is-hiding"), 220);

      hideTitle(viewport);

      if (state.activeIndex === total - 1) {
        if (!state.attemptId) {
            // Attempt creation failed; still show default results so user isn’t stuck
            renderDefaultResults();
            return;
        }

        showSpinner();

        // Build answers payload: one entry per question, with type + value
        const answersPayload = payload.questions.filter((q) => q.type !== "info").map((q) => {
            const qid = String(q.id);
            const t = q.type;

            if (t === "slider") {
            const v = state.answers[qid]?.value ?? 0;
            return { question_id: q.id, type: "slider", value: v };
            } else {
            const oid = state.answers[qid] || null;
            return { question_id: q.id, type: "select", option_id: oid ? Number(oid) : null };
            }
        });

        // Scoring is computed server-side; send answers and receive resultBundle back.
        let resultBundle = {};
        try {
            const data = await apiPost(`/attempts/${state.attemptId}/complete`, {
                quiz_id: payload.quiz.id,
                answers: answersPayload,
            });
            resultBundle = data.resultBundle || {};
        } catch (e) {
            console.error("SlickQuiz: save failed", e);
        } finally {
            hideSpinner();
        }

        renderResults(resultBundle, answersPayload);
        return;
        }

      gotoIndex(state.activeIndex + 1);
    });

    // Initial
    state.currentTranslateY = 0;
    stack.style.transform = "translate3d(0, 0, 0)";
    setInteractivityEnabled(true);

    setTitleForIndex(state.activeIndex);
    updateOverlay();

    // Restore selection UI on first frame (if any)
    const f0 = activeFrame();
    if (f0 && f0.dataset.type !== "slider" && f0.dataset.type !== "info") {
      const qid = f0.dataset.qid;
      setOptionSelectionUI(f0, state.answers[qid] || null);
    }

    window.addEventListener("resize", () => {
      const to = -state.activeIndex * window.innerHeight;
      state.currentTranslateY = to;
      stack.style.transform = `translate3d(0, ${to}px, 0)`;
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".sq-viewport").forEach(initQuiz);
  });
})();