(function ($) {

  // ================================================================
  // Utilities
  // ================================================================

  function slugify(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  }

  // ================================================================
  // Accordion
  // ================================================================

  // $toggle = .sq-item-toggle (flex:1 sibling of the drag handle)
  function expandToggle($toggle) {
    // Collapse siblings at the same level (other .sq-item-toggle elements in the same parent list item's container)
    $toggle.closest('#sq_questions, .sq_options, #sq_vectors, #sq_categories')
      .find('> * > .sq-item-toggle').not($toggle).removeClass('is-expanded');
    $toggle.addClass('is-expanded');
  }

  function collapseToggle($toggle) {
    $toggle.removeClass('is-expanded');
  }

  $(document).on('click', '.sq-item-header', function (e) {
    if ($(e.target).closest('button, input, select, a').length) return;
    var $toggle = $(this).parent(); // .sq-item-toggle
    if ($toggle.hasClass('is-expanded')) {
      collapseToggle($toggle);
    } else {
      expandToggle($toggle);
    }
  });

  $(document).on('click', '.sq-item-collapse', function () {
    collapseToggle($(this).closest('.sq-item-toggle'));
  });

  // ================================================================
  // Scoring vector state
  // ================================================================

  function getCurrentVectors() {
    var vectors = [];
    $("#sq_vectors .sq-vector-row").each(function () {
      var $r    = $(this);
      var key   = $r.find(".sq-vec-key").val().trim();
      var label = $r.find(".sq-vec-label").val().trim();
      var type  = $r.find(".sq-vec-type").val() || "unidirectional";
      var low   = $r.find(".sq-vec-low").val().trim();
      var high  = $r.find(".sq-vec-high").val().trim();
      if (key && label) vectors.push({ key: key, label: label, type: type, low_label: low, high_label: high });
    });
    return vectors;
  }

  // ================================================================
  // Score slider rendering (JS-driven)
  // ================================================================

  function refreshScoreSliders() {
    var vectors = getCurrentVectors();
    $(".sq_scores").each(function () {
      renderScoreSliders(this, vectors);
    });
  }

  function renderScoreSliders(container, vectors) {
    var $c = $(container);

    var current = {};
    $c.find(".sq-score-range").each(function () {
      var vk = $(this).data("vector-key");
      if (vk) current[vk] = $(this).val();
    });

    var dataScores = {};
    try { dataScores = JSON.parse($c.attr("data-scores") || "{}"); } catch (e) {}
    var merged = $.extend({}, dataScores, current);

    var $opt = $c.closest(".slickquiz-option");
    var $q   = $c.closest(".slickquiz-question");
    var $cat = $c.closest(".slickquiz-category");
    var isCategory = $cat.length > 0;

    var qi = parseInt($q.attr("data-qindex"), 10);
    var oi = parseInt($opt.attr("data-oindex"), 10);
    var ci = parseInt($cat.attr("data-catindex"), 10);

    $c.empty();

    if (!vectors.length) {
      $c.html('<p class="sq-scores-empty">Define scoring vectors above to set scores here.</p>');
      return;
    }

    vectors.forEach(function (v) {
      var vk      = v.key;
      var val     = parseFloat(merged[vk] != null ? merged[vk] : 0);
      var min     = (v.type === "bidirectional") ? -1 : 0;
      var max     = 1;
      var namePfx = isCategory
        ? ("categories[" + ci + "][scores][" + vk + "]")
        : ("questions[" + qi + "][options][" + oi + "][scores][" + vk + "]");

      var $row = $('<div class="sq-score-row"></div>');
      var $hdr = $('<div class="sq-score-header"></div>');
      var $lbl = $('<span class="sq-score-vec-label"></span>').text(v.label);
      var $out = $('<output class="sq-score-output"></output>').text(val.toFixed(2));
      $hdr.append($lbl, $out);
      $row.append($hdr);

      var $wrap = $('<div class="sq-score-slider-wrap"></div>');

      if (v.type === "bidirectional" && v.low_label) {
        $wrap.append($('<span class="sq-score-end-label sq-score-end-left"></span>').text(v.low_label));
      }

      var $inp = $('<input type="range" class="sq-score-range" step="0.01" />')
        .attr("min", min).attr("max", max).attr("name", namePfx)
        .attr("data-vector-key", vk).val(val);

      $inp.on("input", function () {
        var n = parseFloat($(this).val());
        $out.text(n.toFixed(2));
        updateSliderBackground(this);
      });

      $wrap.append($inp);

      if (v.type === "bidirectional" && v.high_label) {
        $wrap.append($('<span class="sq-score-end-label sq-score-end-right"></span>').text(v.high_label));
      } else if (v.type === "unidirectional") {
        $wrap.prepend($('<span class="sq-score-end-label sq-score-end-left">0</span>'));
        $wrap.append($('<span class="sq-score-end-label sq-score-end-right">1</span>'));
      }

      $row.append($wrap);
      $c.append($row);
      updateSliderBackground($inp[0]);
    });
  }

  function updateSliderBackground(inp) {
    var min = parseFloat(inp.min);
    var max = parseFloat(inp.max);
    var val = parseFloat(inp.value);
    var pct = ((val - min) / (max - min)) * 100;
    inp.style.background =
      "linear-gradient(to right, #2271b1 0%, #2271b1 " + pct + "%, #ddd " + pct + "%, #ddd 100%)";
  }

  // ================================================================
  // Renumbering
  // ================================================================

  function renumberAll() {
    $("#sq_questions .slickquiz-question").each(function (qi) {
      var $q = $(this);
      $q.attr("data-qindex", qi);

      $q.find('input[name^="questions["], select[name^="questions["]').each(function () {
        var name = $(this).attr("name");
        if (!name) return;
        $(this).attr("name", name
          .replace(/^questions\[\d+\]/, "questions[" + qi + "]")
          .replace(/^questions\[__INDEX__\]/, "questions[" + qi + "]")
        );
      });

      $q.find(".slickquiz-option").each(function (oi) {
        var $o = $(this);
        $o.attr("data-oindex", oi);
        $o.find('input[name^="questions["]').each(function () {
          var name = $(this).attr("name");
          if (!name) return;
          $(this).attr("name", name
            .replace(/questions\[\d+\]\[options\]\[\d+\]/, "questions[" + qi + "][options][" + oi + "]")
            .replace(/questions\[__QINDEX__\]\[options\]\[__OINDEX__\]/, "questions[" + qi + "][options][" + oi + "]")
          );
        });
      });
    });

    refreshScoreSliders();
  }

  function renumberVectors() {
    $("#sq_vectors .sq-vector-row").each(function (vi) {
      var $r = $(this);
      $r.attr("data-vindex", vi);
      $r.find('input[name^="vectors["], select[name^="vectors["]').each(function () {
        var name = $(this).attr("name");
        if (!name) return;
        $(this).attr("name", name
          .replace(/^vectors\[\d+\]/, "vectors[" + vi + "]")
          .replace(/^vectors\[__VINDEX__\]/, "vectors[" + vi + "]")
        );
      });
    });
  }

  function renumberCategorySets() {
    $("#sq_category_tabs .sq-catset-tab").each(function (si) {
      var $r = $(this);
      $r.attr("data-sindex", si);
      $r.find('input[name^="category_sets["]').each(function () {
        var name = $(this).attr("name");
        if (!name) return;
        $(this).attr("name", name
          .replace(/^category_sets\[\d+\]/, "category_sets[" + si + "]")
          .replace(/^category_sets\[__SINDEX__\]/, "category_sets[" + si + "]")
        );
      });
    });
  }

  function renumberCategories() {
    $("#sq_categories .slickquiz-category").each(function (ci) {
      var $c = $(this);
      $c.attr("data-catindex", ci);
      $c.find('input[name^="categories["], select[name^="categories["], textarea[name^="categories["]').each(function () {
        var name = $(this).attr("name");
        if (!name) return;
        $(this).attr("name", name
          .replace(/^categories\[\d+\]/, "categories[" + ci + "]")
          .replace(/^categories\[__CATINDEX__\]/, "categories[" + ci + "]")
        );
      });
    });
    refreshScoreSliders();
  }

  // ================================================================
  // Live summary updates
  // ================================================================

  function itemHeader($item) {
    return $item.find('> .sq-item-toggle > .sq-item-header');
  }

  function updateQuestionSummary($q) {
    var $hdr = itemHeader($q);
    $hdr.find('.sq-summary-title').text($q.find('.sq-question-title-input').val().trim() || 'New question');
    var $ul = $hdr.find('.sq-summary-opts');
    $ul.empty();
    $q.find('.slickquiz-option').each(function () {
      $ul.append($('<li></li>').text($(this).find('.sq-opt-label-input').val().trim() || '—'));
    });
  }

  $(document).on('input', '.sq-question-title-input', function () {
    updateQuestionSummary($(this).closest('.slickquiz-question'));
  });

  $(document).on('input', '.sq-opt-label-input', function () {
    var $opt = $(this).closest('.slickquiz-option');
    itemHeader($opt).find('.sq-summary-title').text($(this).val().trim() || 'New option');
    updateQuestionSummary($opt.closest('.slickquiz-question'));
  });

  $(document).on('input', '.sq-vec-label', function () {
    var $row = $(this).closest('.sq-vector-row');
    itemHeader($row).find('.sq-summary-title').text($(this).val().trim() || 'New vector');
    $row.find('.sq-vec-key').val(slugify($(this).val()));
    refreshScoreSliders();
  });

  $(document).on('input', '.sq-cat-title-input', function () {
    var $cat = $(this).closest('.slickquiz-category');
    itemHeader($cat).find('.sq-summary-title').text($(this).val().trim() || 'New category');
  });

  // ================================================================
  // Sortable
  // ================================================================

  function initOptionSortable($q) {
    $q.find('.sq_options').sortable({
      handle: '.sq-drag-handle',
      items: '.slickquiz-option',
      axis: 'y',
      tolerance: 'pointer',
      update: function () {
        renumberAll();
        updateQuestionSummary($q);
      }
    });
  }

  function initSortables() {
    $("#sq_questions").sortable({
      handle: '.sq-drag-handle',
      items: '.slickquiz-question',
      axis: 'y',
      tolerance: 'pointer',
      update: function () { renumberAll(); }
    });

    $("#sq_questions .slickquiz-question").each(function () {
      initOptionSortable($(this));
    });

    $("#sq_vectors").sortable({
      handle: '.sq-drag-handle',
      items: '.sq-vector-row',
      axis: 'y',
      tolerance: 'pointer',
      update: function () { renumberVectors(); refreshScoreSliders(); }
    });

    $("#sq_categories").sortable({
      handle: '.sq-drag-handle',
      items: '.slickquiz-category',
      axis: 'y',
      tolerance: 'pointer',
      update: function () { renumberCategories(); }
    });
  }

  // ================================================================
  // Category set tab system
  // ================================================================

  function activateTab($tab) {
    $("#sq_category_tabs .sq-catset-tab").removeClass("is-active");
    if ($tab && $tab.length) $tab.addClass("is-active");
    refreshCategoryVisibility();
  }

  function getActiveSetKey() {
    var $active = $("#sq_category_tabs .sq-catset-tab.is-active");
    return $active.length ? ($active.data("setkey") || "") : "";
  }

  function refreshCategoryVisibility() {
    var activeKey = getActiveSetKey();
    $("#sq_categories .slickquiz-category").each(function () {
      var setkey = $(this).data("setkey") || "";
      $(this).toggle(activeKey === "" || setkey === activeKey);
    });
  }

  // ================================================================
  // Questions / options
  // ================================================================

  function enforceTypeOptionCounts($q) {
    var type    = $q.find(".sq_qtype").val();
    var $opts   = $q.find(".sq_options");
    var desired = 2;
    if (type === "select_3") desired = 3;
    if (type === "select_4") desired = 4;
    if (type === "info")     desired = 1;

    while ($opts.find(".slickquiz-option").length < desired) addOption($q, true);
    while ($opts.find(".slickquiz-option").length > desired) $opts.find(".slickquiz-option").last().remove();

    $q.find(".sq_add_option").prop("disabled", true);
    renumberAll();
    updateQuestionSummary($q);
  }

  function addQuestion() {
    var tpl = $("#sq_question_template").html();
    $("#sq_questions").append(tpl);
    renumberAll();
    var $q = $("#sq_questions .slickquiz-question").last();
    enforceTypeOptionCounts($q);
    initOptionSortable($q);
    // Expand new question
    $("#sq_questions .slickquiz-question").not($q).find('> .sq-item-toggle').removeClass('is-expanded');
    $q.find('> .sq-item-toggle').addClass('is-expanded');
  }

  function addOption($q, silent) {
    var tpl = $("#sq_option_template").html();
    $q.find(".sq_options").append(tpl);
    renumberAll();
    updateQuestionSummary($q);
    if (!silent) {
      var $newOpt = $q.find(".slickquiz-option").last();
      $q.find(".slickquiz-option").not($newOpt).find('> .sq-item-toggle').removeClass('is-expanded');
      $newOpt.find('> .sq-item-toggle').addClass('is-expanded');
    }
  }

  function pickImage($btn) {
    var $opt   = $btn.closest(".slickquiz-option");
    var $id    = $opt.find(".sq_image_attachment_id");
    var $thumb = $opt.find(".sq_thumb");
    var frame = wp.media({ title: "Select image", button: { text: "Use this image" }, library: { type: "image" }, multiple: false });
    frame.on("select", function () {
      var att = frame.state().get("selection").first().toJSON();
      $id.val(att.id);
      var url = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url;
      $thumb.html('<img src="' + url + '" alt="" />');
    });
    frame.open();
  }

  function pickInfoImage($btn) {
    var $opt   = $btn.closest(".slickquiz-option");
    var $id    = $opt.find(".sq_info_image_attachment_id");
    var $thumb = $opt.find(".sq_info_thumb");
    var frame = wp.media({ title: "Select info image", button: { text: "Use this image" }, library: { type: "image" }, multiple: false });
    frame.on("select", function () {
      var att = frame.state().get("selection").first().toJSON();
      $id.val(att.id);
      var url = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url;
      $thumb.html('<img src="' + url + '" alt="" />');
    });
    frame.open();
  }

  function pickResultsModule() {
    var $id   = $("#sq_results_module_attachment_id");
    var $info = $("#sq_results_module_info");
    var frame = wp.media({ title: "Select / Upload results module (JS)", button: { text: "Use this file" }, library: { type: "" }, multiple: false });
    frame.on("select", function () {
      var att = frame.state().get("selection").first().toJSON();
      $id.val(att.id);
      $info.html('<div><strong>Selected:</strong> <a href="' + att.url + '" target="_blank" rel="noopener">View file</a></div>');
    });
    frame.open();
  }

  // ================================================================
  // Vector management
  // ================================================================

  function addVector() {
    var tpl = $("#sq_vector_template").html();
    $("#sq_vectors").append(tpl);
    renumberVectors();
    refreshScoreSliders();
    var $new = $("#sq_vectors .sq-vector-row").last();
    $("#sq_vectors .sq-vector-row").not($new).find('> .sq-item-toggle').removeClass('is-expanded');
    $new.find('> .sq-item-toggle').addClass('is-expanded');
  }

  // ================================================================
  // Category set management
  // ================================================================

  function addCatSet() {
    var tpl = $("#sq_catset_tab_template").html();
    $("#sq_category_tabs").append(tpl);
    renumberCategorySets();
    activateTab($("#sq_category_tabs .sq-catset-tab").last());
  }

  // ================================================================
  // Category management
  // ================================================================

  function addCategory() {
    var tpl = $("#sq_category_template").html();
    var activeKey = getActiveSetKey();
    $("#sq_categories").append(tpl);
    var $new = $("#sq_categories .slickquiz-category").last();
    $new.attr("data-setkey", activeKey);
    $new.find(".sq-cat-setkey").val(activeKey);
    renumberCategories();
    refreshCategoryVisibility();
    // Expand new category
    $("#sq_categories .slickquiz-category").not($new).find('> .sq-item-toggle').removeClass('is-expanded');
    $new.find('> .sq-item-toggle').addClass('is-expanded');
  }

  function pickCategoryImage($btn) {
    var $cat   = $btn.closest(".slickquiz-category");
    var $id    = $cat.find(".sq_cat_image_attachment_id");
    var $thumb = $cat.find(".sq_cat_thumb");
    var frame = wp.media({ title: "Select category image", button: { text: "Use this image" }, library: { type: "image" }, multiple: false });
    frame.on("select", function () {
      var att = frame.state().get("selection").first().toJSON();
      $id.val(att.id);
      var url = att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url;
      $thumb.html('<img src="' + url + '" alt="" />');
    });
    frame.open();
  }

  // ================================================================
  // Event bindings
  // ================================================================

  // Questions
  $(document).on("click", "#sq_add_question", function () { addQuestion(); });
  $(document).on("click", ".sq_delete_question", function () {
    $(this).closest(".slickquiz-question").remove();
    renumberAll();
  });
  $(document).on("change", ".sq_qtype", function () {
    var $q = $(this).closest(".slickquiz-question");
    enforceTypeOptionCounts($q);
    $q.find(".sq-info-after-label").toggle($(this).val() !== "info");
  });
  $(document).on("click", ".sq_add_option", function () {
    addOption($(this).closest(".slickquiz-question"));
  });
  $(document).on("click", ".sq_delete_option", function () {
    var $q = $(this).closest(".slickquiz-question");
    $(this).closest(".slickquiz-option").remove();
    enforceTypeOptionCounts($q);
  });

  // Images (options)
  $(document).on("click", ".sq_pick_image", function () { pickImage($(this)); });
  $(document).on("click", ".sq_clear_image", function () {
    var $opt = $(this).closest(".slickquiz-option");
    $opt.find(".sq_image_attachment_id").val("");
    $opt.find(".sq_thumb").html('<div class="sq_thumb_empty">No image</div>');
  });

  // Info images (options)
  $(document).on("click", ".sq_pick_info_image", function () { pickInfoImage($(this)); });
  $(document).on("click", ".sq_clear_info_image", function () {
    var $opt = $(this).closest(".slickquiz-option");
    $opt.find(".sq_info_image_attachment_id").val("");
    $opt.find(".sq_info_thumb").html('<div class="sq_thumb_empty">No image</div>');
  });

  // Info-after checkbox
  $(document).on("change", ".sq-info-after-toggle", function () {
    $(this).closest(".slickquiz-question").toggleClass("sq-has-info-after", this.checked);
  });

  // Results module
  $(document).on("click", "#sq_pick_results_module", function () { pickResultsModule(); });
  $(document).on("click", "#sq_clear_results_module", function () {
    $("#sq_results_module_attachment_id").val("");
    $("#sq_results_module_info").html("<div><em>No file selected.</em></div>");
  });

  // Vectors
  $(document).on("click", "#sq_add_vector", function () { addVector(); });
  $(document).on("click", ".sq_delete_vector", function () {
    $(this).closest(".sq-vector-row").remove();
    renumberVectors();
    refreshScoreSliders();
  });
  $(document).on("change", ".sq-vec-type", function () {
    var $row = $(this).closest(".sq-vector-row");
    $row.find(".sq-vec-bi-labels").toggle($(this).val() === "bidirectional");
    refreshScoreSliders();
  });
  $(document).on("input", ".sq-vec-key, .sq-vec-low, .sq-vec-high", function () {
    refreshScoreSliders();
  });

  // Category set tabs
  $(document).on("click", "#sq_add_catset", function () { addCatSet(); });

  $(document).on("click", ".sq-catset-tab", function (e) {
    if ($(e.target).is(".sq-catset-tab-input") || $(e.target).is(".sq-catset-tab-delete")) return;
    activateTab($(this));
  });

  $(document).on("click", ".sq-catset-tab-delete", function (e) {
    e.stopPropagation();
    var $tab = $(this).closest(".sq-catset-tab");
    var setkey = $tab.data("setkey") || "";
    if (setkey) $("#sq_categories .slickquiz-category[data-setkey='" + setkey + "']").remove();
    var wasActive = $tab.hasClass("is-active");
    $tab.remove();
    renumberCategorySets();
    renumberCategories();
    if (wasActive) activateTab($("#sq_category_tabs .sq-catset-tab").first());
  });

  $(document).on("input", ".sq-catset-tab-input", function () {
    var $tab   = $(this).closest(".sq-catset-tab");
    var oldKey = $tab.data("setkey") || "";
    var newKey = slugify($(this).val());
    $tab.attr("data-setkey", newKey);
    $tab.find(".sq-catset-key").val(newKey);
    if (oldKey !== newKey) {
      $("#sq_categories .slickquiz-category").each(function () {
        if ($(this).data("setkey") === oldKey) {
          $(this).attr("data-setkey", newKey);
          $(this).find(".sq-cat-setkey").val(newKey);
        }
      });
    }
  });

  // Categories
  $(document).on("click", "#sq_add_category", function () { addCategory(); });
  $(document).on("click", ".sq_delete_category", function () {
    $(this).closest(".slickquiz-category").remove();
    renumberCategories();
  });
  $(document).on("click", ".sq_pick_cat_image", function () { pickCategoryImage($(this)); });
  $(document).on("click", ".sq_clear_cat_image", function () {
    var $cat = $(this).closest(".slickquiz-category");
    $cat.find(".sq_cat_image_attachment_id").val("");
    $cat.find(".sq_cat_thumb").html('<div class="sq_thumb_empty">No image</div>');
  });

  // ================================================================
  // Wizard tabs
  // ================================================================

  $(document).on("click", ".sq-wizard-tab", function () {
    var panelId = $(this).data("panel");
    $(".sq-wizard-tab").removeClass("is-active");
    $(".sq-wizard-panel").removeClass("is-active");
    $(this).addClass("is-active");
    $("#" + panelId).addClass("is-active");
  });

  // ================================================================
  // Init on load
  // ================================================================

  $(function () {
    $("#sq_questions .slickquiz-question").each(function () {
      var $q = $(this);
      enforceTypeOptionCounts($q);
      if ($q.find(".sq_qtype").val() === "info") $q.find(".sq-info-after-label").hide();
    });
    renumberAll();
    renumberVectors();
    renumberCategorySets();
    renumberCategories();
    refreshScoreSliders();
    activateTab($("#sq_category_tabs .sq-catset-tab").first());
    initSortables();
  });

})(jQuery);
