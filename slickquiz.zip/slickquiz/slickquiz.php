<?php
/**
 * Plugin Name: SlickQuiz
 * Description: Image-first quizzes with animated transitions and results modules.
 * Version: 0.5.0
 */

if (!defined('ABSPATH')) exit;

define('SLICKQUIZ_VERSION', '0.5.0');
define('SLICKQUIZ_PATH', plugin_dir_path(__FILE__));
define('SLICKQUIZ_URL', plugin_dir_url(__FILE__));

/**
 * Debug flag: define('SLICKQUIZ_DEBUG', true); in wp-config.php
 */
if (!defined('SLICKQUIZ_DEBUG')) define('SLICKQUIZ_DEBUG', false);

function sq_log($msg, $context = []) {
    if (!SLICKQUIZ_DEBUG) return;
    $line = '[SlickQuiz] ' . $msg;
    if (!empty($context)) $line .= ' ' . wp_json_encode($context);
    error_log($line);
}

require_once SLICKQUIZ_PATH . 'includes/Activator.php';
require_once SLICKQUIZ_PATH . 'includes/Repos/QuizRepo.php';
require_once SLICKQUIZ_PATH . 'includes/Admin.php';
require_once SLICKQUIZ_PATH . 'includes/Public.php';
require_once SLICKQUIZ_PATH . 'includes/PublicRoutes.php';
require_once SLICKQUIZ_PATH . 'includes/Api.php';

register_activation_hook(__FILE__, ['SlickQuiz_Activator', 'activate']);

add_action('plugins_loaded', function () {
    SlickQuiz_Activator::maybe_upgrade();

    new SlickQuiz_PublicRoutes();
    new SlickQuiz_Api();

    if (is_admin()) {
        new SlickQuiz_Admin();
    }
});
